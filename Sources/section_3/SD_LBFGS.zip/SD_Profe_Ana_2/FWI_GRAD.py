# -*- coding: utf-8 -*-
"""
Modified on Wed Nov 16 17:22:00 2024

@author: SERGIO ABREO
"""

from propagator_v2 import propagator_v2
from propagator1_v2 import propagator1_v2
import numpy as np
from numpy import linalg as LA
import matplotlib.pyplot as plt


def FWI_GRAD(x, Nx, Nz, Nt, g1, Sx1, Sz, dx, dz, dt, borde, frec, Pt_obs,ad, rx, rz):

    # Propagación del frente de onda sobre el modelo de velocidad
    Pt_mod,P_mod,d2P_dt2 = propagator_v2(np.reshape(x[:],(Nx,Nz),order='F'), g1, Sx1, Sz, dx, dz, dt, borde, frec, rx,rz)
    
    #a1,a2 =np.shape(Pt_mod)
    #print('aca va bien')
    #print(a2)
    #plt.imshow(Pt_mod, extent=[0,156,0,Nt],aspect='auto')
    #plt.title('Trazas Modeladas')
    #plt.colorbar()
    #plt.show()
    # 1) Cálculo de la función en el punto
    f = np.dot(0.5*(np.reshape(Pt_mod,(Nt*156,1),order='F') - np.reshape(Pt_obs,(Nt*156,1),order='F')).T,(np.reshape(Pt_mod,(Nt*156,1),order='F') - np.reshape(Pt_obs,(Nt*156,1),order='F')))
    
    # 2) Cálculo y visualización del residual
    res = Pt_obs-Pt_mod
    #res = Pt_mod-Pt_obs
    #plt.imshow(res, extent=[0,Nt,0,156],aspect='auto')
    #plt.title('residuales')
    #plt.colorbar()
    #plt.show()
    #res1=np.fliplr(res)
    #plt.imshow(res1, extent=[0,Nt,0,156],aspect='auto')
    #plt.title('residuales fliped')
    #plt.colorbar()
    #plt.show()
    #res = np.nan_to_num(res, nan=0)
    #data = np.loadtxt('data.txt', dtype=np.uint8)
    data = np.genfromtxt('Mask_US.txt', dtype=np.float64, delimiter=',')
    mask = np.array(data)
    first_mask = mask[:43264]
    matrix_mask = np.reshape(first_mask[:],(Nx,Nz),order='F')
    #plt.imshow(matrix_mask, extent=[0,Nx,0,Nz],aspect='auto')
    #plt.title('Gradient')
    #plt.colorbar()
    #plt.show()
    #exit(0)
    #resmax = np.max(np.max(res))
    #resmin = np.min(np.min(res))
    #print(data)
    #print(resmin)
    #temp = np.flipud(res)
    #a1, a2 =np.shape(matrix_mask)
    #print(a1) 
    #print(a2)
    #exit(0)
    
    # 3) Retropropagación del residual
    Pt_back = propagator1_v2(np.reshape(x[:],(Nx,Nz),order='F'), np.fliplr(res), np.arange(20,Nx-60,1), Sz, dx, dz, dt,borde, frec, rx, rz)
    #Ptemp = Pt_back[1]
    #Ptemp= np.reshape(Ptemp,(Nx*Nz*Nt,1),order='F')
    #np.savetxt('campoback.txt',Ptemp) 
    #exit(0)

    #plt.imshow(Pt_back[0], extent=[0,20,0,Nt],aspect='auto')
    #plt.title('Trazas')
    #plt.colorbar()
    #plt.show()
    #P_temp = np.array(Pt_back[0][:,:])
    #xa,ya = np.shape(P_temp)
    #print(xa)
    #print(ya)
    #exit(0)
    #Pt_back = propagator1(np.reshape(x[:],(Nx,Nsz),order='F'), np.flipud(res), Sx1, Sz, dx, dz, dt,borde, frec, rx, rz)

    #rows = len(Pt_back)
    #cols = len(Pt_back[0]) if rows > 0 else 0
    #depths = len(Pt_back[0][0]) if cols > 0 else 0
    
    #print(f"Array dimensions: {rows}, {cols}, {depths}")
    
    P_back_t = np.zeros((Nx,Nz,Nt))
    #P_temp = np.array(Pt_back[0][:,:])
    #xa,ya,za = np.shape(P_temp)
    #print(xa)
    #print(ya)
    #print(za)
    for it in range(0,Nt-1):
        P_back_t[:,:,it]=Pt_back[1][:,:,Nt-it-1]
    

    # 5) Cálculo del gradiente normal
    c = np.reshape(x[:],(Nx,Nz),order='F')
    gradienta = np.zeros((Nx, Nz), dtype=np.float64)
    gradienta = -dt*(2/(c**3))*np.sum(P_back_t*d2P_dt2,axis=2)
    #plt.imshow(gradienta, extent=[0,Nx,0,Nz],aspect='auto')
    #plt.title('Gradient')
    #plt.colorbar()
    #plt.show()
    
    #np.savetxt('gradient.txt', gradienta)
    #gradientf=gradienta*(1/LA.norm(gradienta,2))*100
    #gradient_no_nan = np.nan_to_num(gradient, nan=0)
    
    #gradient = gradienta
    gradient = gradienta*matrix_mask
    
    #plt.imshow(gradient, extent=[0,Nx,0,Nz],aspect='auto')
    #plt.title('Gradient')
    #plt.colorbar()
    #plt.show()
    
    #plt.imshow(gradient, extent=[0,Nx,0,Nz],aspect='auto')
    #plt.title('Gradient')
    #plt.colorbar()
    #plt.show()
    #plt.imshow(gradientf, extent=[0,Nx,0,Nz],aspect='auto')
    #plt.title('Gradient')
    #plt.colorbar()
    #plt.show()
    
    #plt.imshow(gradient, extent=[0,Nx,0,Nz],aspect='auto')
    #plt.title('Gradient')
    #plt.colorbar()
    #plt.show()
    
    
    #matrix_no_nan = np.nan_to_num(gradient, nan=0)
    #print(gradient)
    #exit(0)
    #gradient = gradient_norm*matrix_mask
    #plt.imshow(gradient, extent=[0,Nx,0,Nz],aspect='auto')
    #plt.title('Gradient')
    #plt.colorbar()
    #plt.show()
    #exit(0)
    #gradient[Sx1-1,Sz-1]=gradient[Sx1-2,Sz-1]
    #gradient[Sx1,Sz]=gradient[Sx1-2,Sz-1]
    #gradient[Sx1-1,Sz]=gradient[Sx1-2,Sz-1]
    
    #gradient=gradient*(1/LA.norm(gradient,2))
    
    # Recomendación profesora Clara
    g=np.reshape(gradient,(Nx*Nz),order='F')

    
    
    # Visualización del gradiente
    #  figure; 
    #  imagesc(1e-3*dx*(1:Nx),1e-3*dz*(1:Nz),gradient')
    #  caxis(5*[-1 1]), axis equal, axis tight, grid on, axis([0 5.2 0 1.7]), colorbar
    #  xlabel('Distance (km)'), ylabel('Depth (km)'), title('Gradient'), drawnow
    
    #  figure
    #  mesh(gradient)
    #  view(0,0)
    return f,g
