# -*- coding: utf-8 -*-
"""
Modified on Wed Nov 16 17:22:00 2024

@author: SERGIO ABREO
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from propagator_v2 import propagator_v2
from FWI_GRAD import FWI_GRAD
import timeit
from sys import exit
import pickle



#%%
Nx = 208
Nz = 208 
borde = 40

dt = 0.000000345023051/2
frec = 90000
Nt=  1600
tEnd = (Nt-1)*dt
t = np.linspace(0, tEnd, 1600)
#t = np.arange(0,tEnd-dt,dt)
#print(t.shape)
dz = 0.00213313313822/2
dx = dz
vp_ori = np.zeros((Nx,Nz))
vp_ite = np.zeros((Nx,Nz))

#rx = np.array([148, 146, 140, 130, 117, 103, 89, 76, 66, 60, 58, 60, 66, 76, 89, 103, 117,130,140, 146])
#rz = np.array([103, 117, 130, 140, 146, 148, 146, 140, 130, 117, 103, 89,76,66,60,58,60,66,76,89])
Transd = np.genfromtxt('Trans_US_157.txt', dtype=np.uint8, delimiter=',')
Transd1 = np.array(Transd)
Transd2 = Transd1.astype(np.int64)
Transd3 = Transd2[:314]
#print(Transd2.shape)
Transd3 = np.reshape(Transd3,(157,2),order='C')
#print(Transd3.shape)
#Transd_2 = np.array(Transd_2)
rx = Transd3[:,0]
rz = Transd3[:,1]
#print(rx)
#print(rz)
Sx = np.array([rx[0],rx[30],rx[60],rx[105],rx[135]])
Sz = np.array([rz[0],rz[30],rz[60],rz[105],rz[135]])
#
#Sx = np.array([rx[0],rx[15],rx[30],rx[45],rx[60],rx[80],rx[105],rx[120],rx[135],rx[150]])
#Sz = np.array([rz[0],rz[15],rz[30],rz[45],rz[60],rz[80],rz[105],rz[120],rz[135],rz[150]])
#print(Sx)
#print(Sz)
#exit(0)
#Sz = 3
#beta1 = 1000000000
beta1 = 8e8

f1 = 0
f2 = 0
f3 = 0
f4 = 0
f5 = 0
f6 = 0
f7 = 0
f8 = 0
f9 = 0
f10 = 0
grad1 = np.zeros((Nx*Nz,1))
grad2 = np.zeros((Nx*Nz,1)) 
grad3 = np.zeros((Nx*Nz,1)) 
grad4 = np.zeros((Nx*Nz,1)) 
grad5 = np.zeros((Nx*Nz,1)) 
grad6 = np.zeros((Nx*Nz,1))
grad7 = np.zeros((Nx*Nz,1)) 
grad8 = np.zeros((Nx*Nz,1)) 
grad9 = np.zeros((Nx*Nz,1)) 
grad10 = np.zeros((Nx*Nz,1)) 




a = (np.pi*frec*1/3)**2
t0 = 3/frec
g1 = (np.cos(np.pi*frec*2*(t-t0))*np.exp(-a*(t-t0)**2)).T
g1 = np.reshape(g1,(np.size(g1),1))
plt.plot(t,g1)
plt.show()
#exit(0)
# Creación del modelo de velocidades original

#for iz in range(0,Nz):
#    vp_ori[:,iz] = 1520#+0.2*dz*(iz)
#Lectura del modelo de velocidad origina
data = np.genfromtxt('Vp_ori_US.txt', dtype=np.float64, delimiter=',')
vp_ori_temp = np.array(data)
vp_first_ori = vp_ori_temp[:43264]
vp_ori = np.reshape(vp_first_ori[:],(Nx,Nz),order='F')
#plt.imshow(vp_ori, extent=[0,Nx,0,Nz],aspect='auto')
#plt.title('Ground Truth')
#plt.colorbar()
#plt.show()
#v11,v22 = np.shape(vp_ori)
#X,Y = np.meshgrid(np.arange(0,v22,1), np.arange(0,v11,1))
#fig, ax = plt.subplots(subplot_kw={"projection": "3d"},figsize=(10,10))
#surf = ax.plot_surface(X,Y,vp_ori,cmap=cm.coolwarm,linewidth=5) 
#plt.show()
Data_type =  object
#%% Adquisición sobre el modelo original
start=timeit.default_timer()

rx_mod = np.delete(rx, 0)
rz_mod = np.delete(rz, 0)
Pt_obs1 = propagator_v2(vp_ori, g1, Sx[0], Sz[0], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#Ptemp =Pt_obs1[1]
#Ptemp = np.reshape(Ptemp,(Nx*Nz*Nt),order='C')
#np.savetxt('campo3.txt', Ptemp)
#exit(0)
#print(Pt_obs1[0].shape)
rx_mod = np.delete(rx, 30)
rz_mod = np.delete(rz, 30)
Pt_obs2 = propagator_v2(vp_ori, g1, Sx[1], Sz[1], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#print(Pt_obs2[0].shape)
rx_mod = np.delete(rx, 60)
rz_mod = np.delete(rz, 60)
Pt_obs3 = propagator_v2(vp_ori, g1, Sx[2], Sz[2], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#print(Pt_obs3[0].shape)
rx_mod = np.delete(rx, 105)
rz_mod = np.delete(rz, 105)
Pt_obs4 = propagator_v2(vp_ori, g1, Sx[3], Sz[3], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#print(Pt_obs4[0].shape)
rx_mod = np.delete(rx, 135)
rz_mod = np.delete(rz, 135)
Pt_obs5 = propagator_v2(vp_ori, g1, Sx[4], Sz[4], dx, dz, dt, borde, frec,rx_mod,rz_mod)

#rx_mod = np.delete(rx, 80)
#rz_mod = np.delete(rz, 80)
#Pt_obs6 = propagator_v2(vp_ori, g1, Sx[5], Sz[5], dx, dz, dt, borde, frec,rx,rz)
#print(Pt_obs1[0].shape)
#rx_mod = np.delete(rx, 105)
#rz_mod = np.delete(rz, 105)
#Pt_obs7 = propagator_v2(vp_ori, g1, Sx[6], Sz[6], dx, dz, dt, borde, frec,rx,rz)
#print(Pt_obs2[0].shape)
#rx_mod = np.delete(rx, 120)
#rz_mod = np.delete(rz, 120)
#Pt_obs8 = propagator_v2(vp_ori, g1, Sx[7], Sz[7], dx, dz, dt, borde, frec,rx,rz)
#print(Pt_obs3[0].shape)
#rx_mod = np.delete(rx, 135)
#rz_mod = np.delete(rz, 135)
#Pt_obs9 = propagator_v2(vp_ori, g1, Sx[8], Sz[8], dx, dz, dt, borde, frec,rx,rz)
#print(Pt_obs4[0].shape)
#rx_mod = np.delete(rx, 150)
#rz_mod = np.delete(rz, 150)
#Pt_obs10 = propagator_v2(vp_ori, g1, Sx[9], Sz[9], dx, dz, dt, borde, frec,rx,rz)
#print(Pt_obs5[0].shape)
stop=timeit.default_timer()
print('time:', stop-start)

#%% Creación del modelo de velocidad inicial
#plt.imshow(Pt_obs1[0], extent=[0,157,0,Nt],aspect='auto')
#plt.title('Trazas')
#plt.colorbar()
#plt.show()
#plt.imshow(Pt_obs2[0], extent=[0,157,0,Nt],aspect='auto')
#plt.title('Trazas')
#plt.colorbar()
#plt.show()
#plt.imshow(Pt_obs3[0], extent=[0,157,0,Nt],aspect='auto')
#plt.title('Trazas')
#plt.colorbar()
#plt.show()
#plt.imshow(Pt_obs4[0], extent=[0,157,0,Nt],aspect='auto')
#plt.title('Trazas')
#plt.colorbar()
#plt.show()
#plt.imshow(Pt_obs5[0], extent=[0,157,0,Nt],aspect='auto')
#plt.title('Trazas')
#plt.colorbar()
#plt.show()
#exit(0)
#for iz in range(0,Nz):
#    vp_ite[:,Nz-iz-1] = 3172.5-0.2*dz*(iz)
#Usar como modelo inicial una capa constante
vp_ite = np.full((Nx, Nz), 1520)

v33,v44 = np.shape(vp_ite)
#X1,Y1 = np.meshgrid(np.arange(0,v44,1), np.arange(0,v33,1))
#fig, ax = plt.subplots(subplot_kw={"projection": "3d"},figsize=(10,10))
#surf = ax.plot_surface(X1,Y1,vp_ite,cmap=cm.coolwarm,linewidth=5) 
X,Y = np.meshgrid(np.arange(0,v44,1), np.arange(0,v33,1))
#surf = ax.plot_surface(X,Y,vp_ori,cmap=cm.coolwarm,linewidth=5) 
#plt.show()

#%%
start=timeit.default_timer()
FF = 50
f = np.zeros(FF)
temp_grad =np.zeros((Nx,Nz))
for i in range(0,FF):
    vp_ite1 = np.reshape(vp_ite,(Nx*Nz), order='F')
    # Cálculo del gradiente y función objetivo para la adquisición
    #1
    rx_mod = np.delete(rx, 0)
    rz_mod = np.delete(rz, 0)
    f1,grad1 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[0], Sz[0], dx, dz, dt, borde, frec, Pt_obs1[0], 0, rx_mod, rz_mod) 
    #exit(0)
    # ad=0
    #2
    rx_mod = np.delete(rx, 30)
    rz_mod = np.delete(rz, 30)
    f2,grad2 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[1], Sz[1], dx, dz, dt, borde, frec, Pt_obs2[0], 0, rx_mod, rz_mod) # ad=0
    ##3
    rx_mod = np.delete(rx, 60)
    rz_mod = np.delete(rz, 60)
    f3,grad3 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[2], Sz[2], dx, dz, dt, borde, frec, Pt_obs3[0], 0, rx_mod, rz_mod) # ad=0
    #4
    rx_mod = np.delete(rx, 105)
    rz_mod = np.delete(rz, 105)
    f4,grad4 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[3], Sz[3], dx, dz, dt, borde, frec, Pt_obs4[0], 0, rx_mod, rz_mod) # ad=0
    #5
    rx_mod = np.delete(rx, 135)
    rz_mod = np.delete(rz, 135)
    f5,grad5 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[4], Sz[4], dx, dz, dt, borde, frec, Pt_obs5[0], 0, rx_mod, rz_mod) # ad=0
    
    #rx_mod = np.delete(rx, 80)
    #rz_mod = np.delete(rz, 80)
    #f6,grad6 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[5], Sz[5], dx, dz, dt, borde, frec, Pt_obs6[0], 0, rx, rz) 
    # ad=0
    #2
    ##rx_mod = np.delete(rx, 105)
    #rz_mod = np.delete(rz, 105)
    #f7,grad7 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[6], Sz[6], dx, dz, dt, borde, frec, Pt_obs7[0], 0, rx, rz) # ad=0
    ##3
    #rx_mod = np.delete(rx, 120)
    #rz_mod = np.delete(rz, 120)
    #f8,grad8 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[7], Sz[7], dx, dz, dt, borde, frec, Pt_obs8[0], 0, rx, rz) # ad=0
    #4
    #rx_mod = np.delete(rx, 135)
    #rz_mod = np.delete(rz, 135)
    #f9,grad9 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[8], Sz[8], dx, dz, dt, borde, frec, Pt_obs9[0], 0, rx, rz) # ad=0
    #5
    #rx_mod = np.delete(rx, 150)
    #rz_mod = np.delete(rz, 150)
    #f10,grad10 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[9], Sz[9], dx, dz, dt, borde, frec, Pt_obs10[0], 0, rx, rz)



    # función objetivo total y gradiente total
    f[i] = f1 + f2 + f3 + f4 + f5 # +f6 + f7+ f8+f9+f10
    print('Costo', f[i])
    # Aplicando el factor de escala
    grad = grad1 + grad2 + grad3 + grad4 + grad5 #+grad6 + grad7 +grad8 +grad9 + grad10
    #grad = grad1 
    grad = beta1*grad
    temp_grad = np.reshape(grad[:],(Nx,Nz),order='F')
    #plt.imshow(temp_grad, extent=[0,Nx,0,Nz],aspect='auto')
    #plt.title('Gradiente total')
    #plt.colorbar()
    #plt.show()
    ##temp_##grad =grad[np.arange(borde+1,Nx-borde+1,1),np.arange(borde+1,Nz-borde+1,1)]
    # Actualizando el modelo de velocidades
    vp_ite = vp_ite - np.reshape(grad[:],(Nx,Nz),order='F')
    
    #v55,v66 = np.shape(vp_ite)
    #X2,Y2 = np.meshgrid(np.arange(0,v66,1), np.arange(0,v55,1))
    #fig, ax = plt.subplots(subplot_kw={"projection": "3d"},figsize=(10,10))
    #surf = ax.plot_surface(X2,Y2,vp_ite,cmap=cm.nipy_spectral,linewidth=5) 
    #surf = ax.plot_surface(X,Y,vp_ori,cmap=cm.coolwarm,linewidth=5,alpha=0.8) 
    #plt.show()
stop=timeit.default_timer()
print('time:', stop-start)   
##%% Grafica del modelo de velocidades actualizado vs original
# v55,v66 = np.shape(vp_ite)
# np.savetxt('vp_final.txt', vp_ite)
# np.savetxt('fcosto.txt', f)
# X2,Y2 = np.meshgrid(np.arange(0,v66,1), np.arange(0,v55,1))
# fig, ax = plt.subplots(subplot_kw={"projection": "3d"},figsize=(10,10))
# surf = ax.plot_surface(X2,Y2,vp_ite,cmap=cm.nipy_spectral,linewidth=5) 
# surf = ax.plot_surface(X,Y,vp_ori,cmap=cm.coolwarm,linewidth=5,alpha=0.8) 
# plt.show()

#plt.imshow(vp_ite, extent=[0,Nx,0,Nz],aspect='auto')
#plt.title('FWI Output')
#plt.colorbar()
#plt.show()


# Grafica de funcion de costo
plt.figure()
plt.plot(f)
plt.title("Función de costo")
plt.xlabel("iteraciones")
plt.show()


# GRafica de odelo de velocidades estimmados
vmin = np.min(vp_ori)
vmax = np.max(vp_ori)

# Graficar modelo original vp_ori
plt.figure()
plt.imshow(vp_ori, cmap='viridis', interpolation='none', vmin=vmin, vmax=vmax)
plt.colorbar(label="Valor")  # Barra de color para mostrar los valores
plt.title("Vp mod")
plt.xlabel("x")
plt.ylabel("z")
plt.show()

# Graficar modelo obtenido
plt.figure()
plt.imshow(vp_ite, cmap='viridis', interpolation='none', vmin=vmin, vmax=vmax)
plt.colorbar(label="Valor")  # Barra de color para mostrar los valores
plt.title("Vp mod")
plt.xlabel("x")
plt.ylabel("z")
plt.show()
