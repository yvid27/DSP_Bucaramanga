# -*- coding: utf-8 -*-
"""
Modified on Wed Nov 16 17:22:00 2024

@author: SERGIO ABREO
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from propagator_v2 import propagator_v2
from FWI_GRAD import FWI_GRAD
import timeit
from sys import exit
import pickle


#%%
def Objective(vp_ite1):
    
    #vp_ite1 = np.reshape(vp_ite,(Nx*Nz), order='F')
    # Cálculo del gradiente y función objetivo para la adquisición
    #1
    rx_mod = np.delete(rx, 0)
    rz_mod = np.delete(rz, 0)
    f1,grad1 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[0], Sz[0], dx, dz, dt, borde, frec, Pt_obs1[0], 0, rx_mod, rz_mod) 
    #exit(0)
    # ad=0
    #2
    rx_mod = np.delete(rx, 30)
    rz_mod = np.delete(rz, 30)
    f2,grad2 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[1], Sz[1], dx, dz, dt, borde, frec, Pt_obs2[0], 0, rx_mod, rz_mod) # ad=0
    ##3
    rx_mod = np.delete(rx, 60)
    rz_mod = np.delete(rz, 60)
    f3,grad3 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[2], Sz[2], dx, dz, dt, borde, frec, Pt_obs3[0], 0, rx_mod, rz_mod) # ad=0
    #4
    rx_mod = np.delete(rx, 105)
    rz_mod = np.delete(rz, 105)
    f4,grad4 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[3], Sz[3], dx, dz, dt, borde, frec, Pt_obs4[0], 0, rx_mod, rz_mod) # ad=0
    #5
    rx_mod = np.delete(rx, 135)
    rz_mod = np.delete(rz, 135)
    f5,grad5 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[4], Sz[4], dx, dz, dt, borde, frec, Pt_obs5[0], 0, rx_mod, rz_mod) # ad=0

    # función objetivo total y gradiente total
    f = f1 + f2 + f3 + f4 + f5 # +f6 + f7+ f8+f9+f
    
    # Gradiente con escala
    grad = grad1 + grad2 + grad3 + grad4 + grad5 #+grad6 + grad7 +grad8 +grad9 + grad10
    #grad = grad1 
    grad = beta1*grad
    
    # Graficar gradiente
    temp_grad = np.reshape(grad[:],(Nx,Nz),order='F')
    plt.figure()
    plt.imshow(temp_grad, cmap='viridis', interpolation='none', aspect='auto')
    plt.colorbar(label="Valor")  # Barra de color para mostrar los valores
    plt.title("Gradiente")
    plt.xlabel("z")
    plt.ylabel("x")
    plt.show()
    
    print ("norma L2 del gradiente",np.linalg.norm(grad, 2)) 
    
    return f.item(),grad

#%%
Nx = 208
Nz = 208 
borde = 40

dt = 0.000000345023051/2
frec = 90000
Nt=  1600
tEnd = (Nt-1)*dt
t = np.linspace(0, tEnd, 1600)
#t = np.arange(0,tEnd-dt,dt)
#print(t.shape)
dz = 0.00213313313822/2
dx = dz
vp_ori = np.zeros((Nx,Nz))
vp_ite = np.zeros((Nx,Nz))

Transd = np.genfromtxt('Trans_US_157.txt', dtype=np.uint8, delimiter=',')
Transd1 = np.array(Transd)
Transd2 = Transd1.astype(np.int64)
Transd3 = Transd2[:314]
#print(Transd2.shape)
Transd3 = np.reshape(Transd3,(157,2),order='C')
#print(Transd3.shape)
#Transd_2 = np.array(Transd_2)
rx = Transd3[:,0]
rz = Transd3[:,1]
#print(rx)
#print(rz)
Sx = np.array([rx[0],rx[30],rx[60],rx[105],rx[135]])
Sz = np.array([rz[0],rz[30],rz[60],rz[105],rz[135]])
#
beta1 = 8e8

f1 = 0
f2 = 0
f3 = 0
f4 = 0
f5 = 0

# Definicion de la fuente
a = (np.pi*frec*1/3)**2
t0 = 3/frec
g1 = (np.cos(np.pi*frec*2*(t-t0))*np.exp(-a*(t-t0)**2)).T
g1 = np.reshape(g1,(np.size(g1),1))
plt.plot(t,g1)
plt.show()

#%% Creación del modelo de velocidades origina

#Lectura del modelo de velocidad origina
data = np.genfromtxt('Vp_ori_US.txt', dtype=np.float64, delimiter=',')
vp_ori_temp = np.array(data)
vp_first_ori = vp_ori_temp[:43264]
vp_ori = np.reshape(vp_first_ori[:],(Nx,Nz),order='F')

#%% Adquisición sobre el modelo original
start=timeit.default_timer()

rx_mod = np.delete(rx, 0)
rz_mod = np.delete(rz, 0)
Pt_obs1 = propagator_v2(vp_ori, g1, Sx[0], Sz[0], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#print(Pt_obs1[0].shape)
rx_mod = np.delete(rx, 30)
rz_mod = np.delete(rz, 30)
Pt_obs2 = propagator_v2(vp_ori, g1, Sx[1], Sz[1], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#print(Pt_obs2[0].shape)
rx_mod = np.delete(rx, 60)
rz_mod = np.delete(rz, 60)
Pt_obs3 = propagator_v2(vp_ori, g1, Sx[2], Sz[2], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#print(Pt_obs3[0].shape)
rx_mod = np.delete(rx, 105)
rz_mod = np.delete(rz, 105)
Pt_obs4 = propagator_v2(vp_ori, g1, Sx[3], Sz[3], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#print(Pt_obs4[0].shape)
rx_mod = np.delete(rx, 135)
rz_mod = np.delete(rz, 135)
Pt_obs5 = propagator_v2(vp_ori, g1, Sx[4], Sz[4], dx, dz, dt, borde, frec,rx_mod,rz_mod)


stop=timeit.default_timer()
print('Time making True models:', stop-start)

#%% Creación del modelo de velocidad inicial

#Usar como modelo inicial una capa constante
vp_ite = np.full((Nx, Nz), 1520)

v33,v44 = np.shape(vp_ite)
#X1,Y1 = np.meshgrid(np.arange(0,v44,1), np.arange(0,v33,1))
#fig, ax = plt.subplots(subplot_kw={"projection": "3d"},figsize=(10,10))
#surf = ax.plot_surface(X1,Y1,vp_ite,cmap=cm.coolwarm,linewidth=5) 
X,Y = np.meshgrid(np.arange(0,v44,1), np.arange(0,v33,1))
#surf = ax.plot_surface(X,Y,vp_ori,cmap=cm.coolwarm,linewidth=5) 
#plt.show()

#%% Optimizacion del modelo

start=timeit.default_timer()
FF = 20
f = np.zeros(FF)
temp_grad =np.zeros((Nx,Nz))
vp_ite1 = np.reshape(vp_ite, (Nx*Nz), order='F')

for i in range(0,FF):

    f[i],grad = Objective(vp_ite1)
    
    # Actualizando el modelo de velocidades
    vp_ite1 = vp_ite1 - grad
    
    print("iteracion ",i,"  Funcion de costo= ",f[i])
    
stop=timeit.default_timer()
print('Time making estimated models:', stop-start)   

vp_ite_optimized = np.reshape(vp_ite1, (Nx, Nz), order='F')

#%% Grafica del modelo de velocidades actualizado vs original

import os

directorio = "Results/SD/Exp1"


#Grafica de funcion de costo
cost_per_iteration = f
plt.figure()
plt.plot(cost_per_iteration.flatten())  # Graficar los puntos
plt.title('Función de costo')
plt.xlabel('iteraciones')
nombre_archivo = 'F_costo.pdf'     
ruta_completa = os.path.join(directorio, nombre_archivo)
os.makedirs(directorio, exist_ok=True)
plt.savefig(ruta_completa, format="pdf", dpi=400)
plt.show()

# GRafica de odelo de velocidades estimmados
vmin = np.min(vp_ori)
vmax = np.max(vp_ori)

# Graficar modelo original vp_ori
plt.figure()
plt.imshow(vp_ori, cmap='viridis', interpolation='none', vmin=vmin, vmax=vmax)
plt.colorbar(label="Valor")  # Barra de color para mostrar los valores
plt.title("m true")
plt.xlabel("x")
plt.ylabel("z")
nombre_archivo = 'm_ori.pdf'     
ruta_completa = os.path.join(directorio, nombre_archivo)
plt.savefig(ruta_completa, format="pdf", dpi=400)
plt.show()

plt.figure()
plt.imshow(vp_ite, cmap='viridis', interpolation='none', vmin=vmin, vmax=vmax)
plt.colorbar(label="Valor")  # Barra de color para mostrar los valores
plt.title("m inicial")
plt.xlabel("x")
plt.ylabel("z")
nombre_archivo = 'm_initial.pdf'     
ruta_completa = os.path.join(directorio, nombre_archivo)
plt.savefig(ruta_completa, format="pdf", dpi=400)
plt.show()

# Graficar modelo obtenido
plt.figure()
plt.imshow(vp_ite_optimized, cmap='viridis', interpolation='none', vmin=vmin, vmax=vmax)
plt.colorbar(label="Valor")  # Barra de color para mostrar los valores
plt.title("m mod")
plt.xlabel("x")
plt.ylabel("z")
nombre_archivo = 'm_ite_optimized.pdf'     
ruta_completa = os.path.join(directorio, nombre_archivo)
plt.savefig(ruta_completa, format="pdf", dpi=400)
plt.show()