# -*- coding: utf-8 -*-
"""
Modified on Wed Nov 16 17:22:00 2024

@author: SERGIO ABREO
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from propagator_v2 import propagator_v2
from FWI_GRAD import FWI_GRAD
import timeit
from sys import exit
from scipy.optimize import minimize
import pickle
import os


def objective(vp_ite1):
    vp_ite1 = np.reshape(vp_ite,(Nx*Nz), order='F')
    # Cálculo del gradiente y función objetivo para la adquisición
    #1
    rx_mod = np.delete(rx, 0)
    rz_mod = np.delete(rz, 0)
    f1,grad1 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[0], Sz[0], dx, dz, dt, borde, frec, Pt_obs1[0], 0, rx_mod, rz_mod) 
    # ad=0
    #2
    #rx_mod = np.delete(rx, 30)
    #rz_mod = np.delete(rz, 30)
    #f2,grad2 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[1], Sz[1], dx, dz, dt, borde, frec, Pt_obs2[0], 0, rx_mod, rz_mod) # ad=0
    ##3
    #rx_mod = np.delete(rx, 60)
    #rz_mod = np.delete(rz, 60)
    #f3,grad3 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[2], Sz[2], dx, dz, dt, borde, frec, Pt_obs3[0], 0, rx_mod, rz_mod) # ad=0
    #4
    #rx_mod = np.delete(rx, 90)
    #rz_mod = np.delete(rz, 90)
    #f4,grad4 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[3], Sz[3], dx, dz, dt, borde, frec, Pt_obs4[0], 0, rx_mod, rz_mod) # ad=0
    #5
    #rx_mod = np.delete(rx, 120)
    #rz_mod = np.delete(rz, 120)
    #f5,grad5 = FWI_GRAD(vp_ite1, Nx, Nz, Nt, g1, Sx[4], Sz[4], dx, dz, dt, borde, frec, Pt_obs5[0], 0, rx_mod, rz_mod) # ad=0
    
    
    f_total = f1 #+ f2 + f3 + f4 + f5
    
    print("f_attempt = ",f_total.item())
    
    grad_total = grad1 #+ grad2 + grad3 + grad4 + grad5
    #grad_total=np.reshape(grad_total,(Nx,Nz),order='F')
    #g_total = grad_total*matrix_mask
    #g_total=np.reshape(grad_total,(Nx*Nz,1),order='F')
    #grad_total[0:839] = 0 # 4 FILAS
    
    grad_total_temp = np.reshape(grad_total, (Nx, Nz), order='F')
    plt.figure(figsize=(6, 6))
    plt.imshow(grad_total_temp, cmap='viridis', interpolation='none', aspect='auto')
    plt.colorbar(label="Valor")  # Barra de color para mostrar los valores
    plt.title("Gradiente")
    plt.xlabel("z")
    plt.ylabel("x")
    plt.show()
    
    print ("norma L2 del gradiente",np.linalg.norm(grad_total, 2))  
        
    return f_total.item(),100000*grad_total


#%%
Nx = 208
Nz = 208 
borde = 40

dt = 0.000000345023051/2
frec = 90000
Nt=  1600
tEnd = (Nt-1)*dt
t = np.linspace(0, tEnd, 1600)
#t = np.arange(0,tEnd-dt,dt)
#print(t.shape)
dz = 0.00213313313822/2
dx = dz
vp_ori = np.zeros((Nx,Nz))
vp_ite = np.zeros((Nx,Nz))

#rx = np.array([148, 146, 140, 130, 117, 103, 89, 76, 66, 60, 58, 60, 66, 76, 89, 103, 117,130,140, 146])
#rz = np.array([103, 117, 130, 140, 146, 148, 146, 140, 130, 117, 103, 89,76,66,60,58,60,66,76,89])
Transd = np.genfromtxt('Trans_US_157.txt', dtype=np.uint8, delimiter=',')
Transd1 = np.array(Transd)
Transd2 = Transd1.astype(np.int64)
Transd3 = Transd2[:314]
#print(Transd2.shape)
Transd3 = np.reshape(Transd3,(157,2),order='C')
#print(Transd3.shape)
#Transd_2 = np.array(Transd_2)
rx = Transd3[:,0]
rz = Transd3[:,1]
#print(rx)
#print(rz)
Sx = np.array([rx[0],rx[30],rx[60],rx[105],rx[135]])
Sz = np.array([rz[0],rz[30],rz[60],rz[105],rz[135]])
#print(Sx)
#print(Sz)
#exit(0)
#Sz = 3

f1 = 0
f2 = 0
f3 = 0
f4 = 0
f5 = 0
grad1 = np.zeros((Nx*Nz,1))
grad2 = np.zeros((Nx*Nz,1)) 
grad3 = np.zeros((Nx*Nz,1)) 
grad4 = np.zeros((Nx*Nz,1)) 
grad5 = np.zeros((Nx*Nz,1)) 

a = (np.pi*frec*1/3)**2
t0 = 3/frec
g1 = (np.cos(np.pi*frec*2*(t-t0))*np.exp(-a*(t-t0)**2)).T
g1 = np.reshape(g1,(np.size(g1),1))
plt.plot(t,g1)
plt.show()
#exit(0)
# Creación del modelo de velocidades original

#for iz in range(0,Nz):
#    vp_ori[:,iz] = 1520#+0.2*dz*(iz)
#Lectura del modelo de velocidad origina
data = np.genfromtxt('Vp_ori_US.txt', dtype=np.float64, delimiter=',')
vp_ori_temp = np.array(data)
vp_first_ori = vp_ori_temp[:43264]
vp_ori = np.reshape(vp_first_ori[:],(Nx,Nz),order='F')
#plt.imshow(vp_ori, extent=[0,Nx,0,Nz],aspect='auto')
#plt.title('Ground Truth')
#plt.colorbar()
#plt.show()
#v11,v22 = np.shape(vp_ori)
#X,Y = np.meshgrid(np.arange(0,v22,1), np.arange(0,v11,1))
#fig, ax = plt.subplots(subplot_kw={"projection": "3d"},figsize=(10,10))
#surf = ax.plot_surface(X,Y,vp_ori,cmap=cm.coolwarm,linewidth=5) 
#plt.show()
Data_type =  object
#%% Adquisición sobre el modelo original
start=timeit.default_timer()

rx_mod = np.delete(rx, 0)
rz_mod = np.delete(rz, 0)
Pt_obs1 = propagator_v2(vp_ori, g1, Sx[0], Sz[0], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#print(Pt_obs1[0].shape)
#rx_mod = np.delete(rx, 30)
#rz_mod = np.delete(rz, 30)
#Pt_obs2 = propagator_v2(vp_ori, g1, Sx[1], Sz[1], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#print(Pt_obs2[0].shape)
#rx_mod = np.delete(rx, 60)
#rz_mod = np.delete(rz, 60)
#Pt_obs3 = propagator_v2(vp_ori, g1, Sx[2], Sz[2], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#print(Pt_obs3[0].shape)
#rx_mod = np.delete(rx, 90)
#rz_mod = np.delete(rz, 90)
#Pt_obs4 = propagator_v2(vp_ori, g1, Sx[3], Sz[3], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#print(Pt_obs4[0].shape)
#rx_mod = np.delete(rx, 120)
#rz_mod = np.delete(rz, 120)
#Pt_obs5 = propagator_v2(vp_ori, g1, Sx[4], Sz[4], dx, dz, dt, borde, frec,rx_mod,rz_mod)
#print(Pt_obs5[0].shape)
stop=timeit.default_timer()
print('time:', stop-start)
#Ptemp = Pt_obs1[1]
#Ptemp= np.reshape(Ptemp,(Nx*Nz*Nt,1),order='F')
#np.savetxt('campo.txt',Ptemp)
#exit(0)

#%% Creación del modelo de velocidad inicial
#plt.imshow(Pt_obs1[0], extent=[0,156,0,Nt],aspect='auto')
#plt.title('Trazas')
#plt.colorbar()
#plt.show()
#plt.imshow(Pt_obs2[0], extent=[0,156,0,Nt],aspect='auto')
#plt.title('Trazas')
#plt.colorbar()
#plt.show()
#plt.imshow(Pt_obs3[0], extent=[0,156,0,Nt],aspect='auto')
#plt.title('Trazas')
#plt.colorbar()
#plt.show()
#plt.imshow(Pt_obs4[0], extent=[0,156,0,Nt],aspect='auto')
#plt.title('Trazas')
#plt.colorbar()
#plt.show()
#plt.imshow(Pt_obs5[0], extent=[0,156,0,Nt],aspect='auto')
#plt.title('Trazas')
#plt.colorbar()
#plt.show()
#exit(0)
#for iz in range(0,Nz):
#    vp_ite[:,Nz-iz-1] = 3172.5-0.2*dz*(iz)
#Usar como modelo inicial una capa constante
vp_ite = np.full((Nx, Nz), 1520)

#v33,v44 = np.shape(vp_ite)
#X1,Y1 = np.meshgrid(np.arange(0,v44,1), np.arange(0,v33,1))
#fig, ax = plt.subplots(subplot_kw={"projection": "3d"},figsize=(10,10))
#surf = ax.plot_surface(X1,Y1,vp_ite,cmap=cm.coolwarm,linewidth=5) 
#X,Y = np.meshgrid(np.arange(0,v22,1), np.arange(0,v11,1))
#surf = ax.plot_surface(X,Y,vp_ori,cmap=cm.coolwarm,linewidth=5) 
#plt.show()

#%%
cost_per_iteration = []
start=timeit.default_timer()
FF = 50
f = np.zeros(FF)
#temp_grad =np.zeros((Nx,Nz))
vp_ite1 = np.reshape(vp_ite,(Nx*Nz), order='F')

def monitor(xk):
    current_cost, _ = objective(xk)  # Calcular el costo actual
    cost_per_iteration.append(current_cost)  # Guardar el costo en la lista
    print(f"Iteración: {monitor.iter}, Funión de costo: {current_cost}")
    monitor.iter += 1

monitor.iter = 1 

#res = minimize(objective, vp_ite1, method='L-BFGS-B', jac=True,callback=monitor, options={'disp': True, 'maxiter': 40, 'gtol': 1e-12, 'maxls': 40},)
res = minimize(objective, vp_ite1, method='L-BFGS-B', jac=True,callback=monitor, options={'disp': True,'maxiter':20})

vp_ite_optimized = np.reshape(res.x, (Nx, Nz), order='F')
    
    # función objetivo total y gradiente total
    
    # Aplicando el factor de escala
#grad = beta1*grad1 + beta2*grad2 + beta3*grad3 + beta4*grad4 + beta5*grad5
#temp_grad = np.reshape(grad[:],(Nx,Nz),order='F')
    # Actualizando el modelo de velocidades
#vp_ite = vp_ite + np.reshape(grad[:],(Nx,Nz),order='F')
    
    #v55,v66 = np.shape(vp_ite)
    #X2,Y2 = np.meshgrid(np.arange(0,v66,1), np.arange(0,v55,1))
    #fig, ax = plt.subplots(subplot_kw={"projection": "3d"},figsize=(10,10))
    #surf = ax.plot_surface(X2,Y2,vp_ite,cmap=cm.nipy_spectral,linewidth=5) 
    #surf = ax.plot_surface(X,Y,vp_ori,cmap=cm.coolwarm,linewidth=5,alpha=0.8) 
    #plt.show()
stop=timeit.default_timer()
print('time:', stop-start)   
#%% Grafica del modelo de velocidades actualizado vs original
#v55,v66 = np.shape(vp_ite)
#np.savetxt('vp_final.txt', vp_ite)
#X2,Y2 = np.meshgrid(np.arange(0,v66,1), np.arange(0,v55,1))#
#fig, ax = plt.subplots(subplot_kw={"projection": "3d"},figsize=(10,10))
#surf = ax.plot_surface(X2,Y2,vp_ite,cmap=cm.nipy_spectral,linewidth=5) 
#surf = ax.plot_surface(X,Y,vp_ori,cmap=cm.coolwarm,linewidth=5,alpha=0.8) 
#plt.show()

#plt.imshow(vp_ite, extent=[0,Nx,0,Nz],aspect='auto')
#plt.title('FWI Output')
#plt.colorbar()
#plt.show()
