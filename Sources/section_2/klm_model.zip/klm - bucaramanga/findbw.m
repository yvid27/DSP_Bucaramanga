function [bw,f_left,f_right] = findbw(spectrum,freqscale,fpeak);

% Calculate bandwidth of spectrum with peak at frequency INDEX fpeak

f_left = fpeak;
f_right = fpeak;
y = abs(spectrum(fpeak));
while y > abs(spectrum(fpeak)/2) & (f_left>=2)
    f_left = f_left - 1;
    y = abs(spectrum(f_left));
end

y = abs(spectrum(fpeak));
while y > abs(spectrum(fpeak)/2) & (f_right<=length(freqscale)-1)
    f_right = f_right + 1;
    y = abs(spectrum(f_right));
end 
    
bw = freqscale(f_right) - freqscale(f_left);
bw = bw / freqscale(fpeak) * 100;
