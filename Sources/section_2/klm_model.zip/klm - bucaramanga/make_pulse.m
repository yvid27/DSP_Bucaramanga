function WF = make_pulse(transducer,amplitude)

% Make pulse in time domain

numpoints = transducer.boundaries.fnum;
dt = 1 / (transducer.boundaries.fmax*2);
BW = 0.25;
fc = 20e6;
t = (-numpoints+1:numpoints-1)*dt;
v =  amplitude * gauspuls(t,fc,BW);

WF.t = t;
WF.v = v;