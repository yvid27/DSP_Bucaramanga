function [M,transducer_out,freq]=build_xducer(transducer)

% M=build_xducer(layers)
%
% Build up a two-port of the transducer by modeling all the layers according to the KLM
% model, and cascading them into a single two-port.
%
% layers is a 1xn strucure which contains the material properties of all
% layers.
% boundaries is a structure which contains the boundary conditions Rint,
% Zback, Zmedium

% Create frequency scale
layers=transducer.layers;
boundaries=transducer.boundaries;
cable=transducer.cable;

freq = linspace(boundaries.fmin,boundaries.fmax,boundaries.fnum);
omega = 2 * pi * freq;

% Incorporate losses
layers(1).c33d = layers(1).c33d * (1 + j * layers(1).tandelta_m);
layers(1).epsilons = layers(1).epsilons * (1 - j * layers(1).tandelta_e);

% Calculate velocity, Z0, Zc and gamma for each active layer 
for a=1:length(layers)
        if isempty(layers(a).velocity)
            layers(a).velocity = sqrt(layers(a).c33d / layers(a).rho);
        end
        if isempty(layers(a).Z0)
            layers(a).Z0 = layers(a).rho * layers(a).velocity;
        end                
        layers(a).area = pi * (layers(a).diameter / 2) ^ 2;
        
        layers(a).Zc = layers(a).Z0 * layers(a).area;
        
        layers(a).gamma = j .* omega ./ layers(a).velocity;
        if a>1 layers(a).gamma = j .* omega ./ layers(a).velocity .* (1 - j * layers(a).tandelta_m); end
        
end

transducer_out.layers=layers;
transducer_out.boundaries=boundaries;
% -----------------------------------------------------
% Calculate capacitance, inductance and transformer winding ratio of the
% piezoelectric layer according to the KLM model
% -----------------------------------------------------

% dielectric constant of vacuum [C/Vm]
epsilon0 = 8.85419e-12;  

% antiresonant angular frequency [rad]
omega_a = pi * layers(1).velocity / layers(1).thickness;

% capacitance of piezoelectric layer [Farad]
C0 = epsilon0 * layers(1).epsilons * layers(1).area / layers(1).thickness;

% Inductance of piezoelectric layer [Henry]
X1 = layers(1).kt^2 ./ omega / C0 .* sinc(omega / omega_a);

% Transformer winding ratio of piezoelectric layer 
Phi =1 ./ ( layers(1).kt * sqrt( pi ./ omega_a ./ C0 ./ layers(1).Zc) .* sinc( omega ./ 2 ./ omega_a ) );

% -------------------------------------------------------
% Now create the different blocks
% -------------------------------------------------------

% Coax Cable
% Cable damping in dB/m/MHz
v_cable = 0.53; % gemeten waarde
cable.loss = (300e6 * v_cable * cable.damping) ./ (2 * 4.343 * 2 * pi * 1e6);
cable.gamma = j .* omega ./ (300E6 * v_cable) .* (1 - j .* cable.loss);
M_cable=make_tml(cable.Zc,cable.length,cable.gamma);

% Serial Resistance
% Due to Ohmic resistance in passive layers
try 
    Rs = boundaries.Rs; 
catch
    Rs = 0;
end
M_Rs = make_twoport('s','r',Rs,omega);

% Electrical block
% accounts for the capacitance C0 and the inductance X1 of the transducer
M_elec=make_elecpart(C0,X1,omega);

% Transformer block
% transforms the electrical input to mechanical output 
% (Voltage, Current  -> Force, Velocity)
M_xform=make_xform(Phi,omega);

% Dead branch block
% One end of the transmission line represents the back of the transducer
% and is modeled as a shunt impedance. This is necessary since only two
% ports can be modeled.

M_deadbranch=make_deadbranch(transducer_out);

% Transmission line block for piezoelectric layer
% represents the TL behaviour of the piezoelectric layer
M_tml_piezo=make_tml(layers(1).Zc,layers(1).thickness/2,layers(1).gamma);

% Transmission line blocks additional layers
% represents the TL behaviour of the additional layers
M_tml_layers=ones(2,2,boundaries.fnum);   % if no matching layers present
M_tml_layers(1,2,:)=0;M_tml_layers(2,1,:)=0;
for a=2:length(layers)
    if strcmp(lower(layers(a).active),'yes')
        n=layers(a).number;
        M_tml_layers(1:2,2*n-1:2*n,:)=make_tml(layers(a).Zc,layers(a).thickness,layers(a).gamma);
    else
        n=layers(a).number;
        M_tml_layers(1:2,2*n-1:2*n,:)=make_tml(layers(a).Zc,0,layers(a).gamma);
    end
end

% Build a cascade of all blocks
M=connectblocks([M_cable M_Rs M_elec M_xform M_deadbranch M_tml_piezo M_tml_layers]);

