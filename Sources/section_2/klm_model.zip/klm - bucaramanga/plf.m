aantal=0
b=0
%het maken van fase plotjesteleview
aantal=34
hold on
for a =34:aantal
        filename=['\\home\users\gerritd\Data\projecten\televiewer\tdhpc\teleview70\juni2006\70C ' num2str(a) ' kaal vrij '];
        %else
        %filename=['g:\data\Prototype_v3\rond'         %end
   %impdata=y
    impdata=load_data(filename);
    %subplot(5,2,2*a-1)
    freq=impdata(:,1)/1e6;
    mag=abs(complex(impdata(:,2),impdata(:,3)));
    phase=angle(complex(impdata(:,2),impdata(:,3)))*180/pi; 
    % compensate for Cu-probe
      %  realdata = realdata - 0.566 - 3.44E-9 * freqs;                  
       % imagdata = imagdata + 0.02 - 1.67e-7 * freqs;
        % Accuracy +/- 0.02 Ohm
    
    
    if a>14
       b=a
       a=a-15;
    end
    if a==1
       kleur='b';
       end
       if a==2
       kleur='g';
       end
    if a==3
       kleur='r';
       end
    if a==4
       kleur='c';
       end
    if a==5
       kleur='m';
       end
    if a==6
       kleur='y';
       end                     
    if a==7
       kleur='k'
        end
    if a==8
        kleur='b:';
       end
    if a==9
        kleur='g:';
       end
    if a==10
       kleur='r:';
       end
    if a==11
       kleur='c:';
       end
    if a==12
       kleur='m:';
       end
    if a==13
       kleur='y:';      
    end                     
    if a==14
       kleur='k:'; 
    end
    if b>14
        a=a+14;
        b =0;
    end
     
    %plot(impdata(:,1),impdata(:,3),kleur);
    %plot(freq,mag,kleur);
    %grid on;%axis([10 60 0 200]);
    %set(gca,'FontSize',8);
    %xlabel('MHz');ylabel('Magnitude');%legend(['Element no.' num2str(a)]);
    %subplot(5,2,2*a)
    %plot(impdata(:,1),impdata(:,2),kleur);
    plot(freq,phase,kleur);
    grid on;%axis([10 60 -90 0]);
    %set(gca,'FontSize',8);
    xlabel('MHz');ylabel('Phase');
    %legend(['transduser.' num2str(a)]);    
end
hold off