function transducer_out=fit(transducer,impdata,paramlist)

% x = fit(transducer,impdata,varargin)
% Fits transducer model to measured impedance data
% impdata should be a N x 3 array with frequency scale in the first column,
% real data in the second column and imaginary data in the third column.
% Varargin represents the parameters to be fitted. Define layer no., property and initial value
% For example:
%
% x = fit(transducer,impdata,1,'Thickness',60e-6,2,'Z0',10e6)
%
% This will fit the thickness of the first layer and the Z0 of the second
% layer

global COUNT
global F
COUNT = 1; F = 100;

show_xducer(transducer,2)

% read parameters to be fitted
props=paramlist;

% read initial values
lng=length(paramlist)/3;
if lng~=round(lng) error('Invalid Property arguments');end
for a=1:lng
    x0(a)=paramlist{a*3};
end

realdata=impdata(:,2);
imagdata=impdata(:,3);
absdata=abs(complex(realdata,imagdata));
phasedata=angle(complex(realdata,imagdata))*180/pi;

% Do the plotting
scrsz = get(0,'ScreenSize');
figure(3);
set(3,'Name','Transducer Properties','Position',[7 scrsz(4)/3-10 scrsz(3)/1.5 scrsz(4)/1.7],...
    'ButtonDownFcn','close');
subplot(3,1,1)
h1=semilogy(1,1);grid;
%axis([0 60 0 250]);
ylabel('Input Impedance','FontSize',8,'FontWeight','Bold');
h2=line(impdata(:,1)/1e6,realdata);
set(h2,'LineWidth',1,'Color','b');

subplot(3,1,2)
h3=plot(1,1);grid;
%axis([0 60 -250 250]);
ylabel('Input Impedance','FontSize',8,'FontWeight','Bold');
h4=line(impdata(:,1)/1e6,imagdata);
set(h4,'LineWidth',1,'Color','b');

subplot(3,1,3)
h5=plot(1,1);grid;

ylabel('Error','FontSize',8,'FontWeight','Bold');


% Output initial values as plot's title
str=[];
for a=1:length(x0)-1
str=[str '  ' char(props{(a-1)*3+2}) ' = ' num2str(x0(a),2)];
end
title(str,'FontSize',8,'FontWeight','Bold');

% User input
xlabel('Use mouse to select frequency range','Color','r','FontSize',12,'Fontweight','Bold');
input = ginput(1);
line([input(1) input(1)],[0 200]);
range(1) = input(1);
input = ginput(1);
line([input(1) input(1)],[0 200]);
range(2) = input(1);
subplot(3,1,1);axis([range(1) range(2) 0 max(realdata*1.5)]);
subplot(3,1,2);axis([range(1) range(2) min(imagdata) max(imagdata)]);
subplot(3,1,3);axis([0 1000 0 20]);
%set(h3,'XLim',[range(1) range(2)]);


% Set model frequency scale to frequency scale of measured data
transducer.boundaries.fmin=impdata(1,1);
transducer.boundaries.fmax=impdata(length(impdata),1);
transducer.boundaries.fnum=length(impdata);

% Call fitting function
options = optimset('MaxIter',50000,'TolX',1e-6);
x = fminsearch(@fitfnc,x0,options,transducer,impdata,h1,h3,h5,props,range);
transducer_out = transducer;