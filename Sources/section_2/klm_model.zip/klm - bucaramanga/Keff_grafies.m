%Keff in gelezen uit een grafiek
%plaats de cursor op de res frquentie
%plaats de cursor op de antires frequentie

a=ginput(1);
b=ginput(2);
print(a);
K=sqrt((b(:,1)^2-a(:,1)^2)/b(:,1)^2);