function h2=make_plot(plots,fignum,type)

% make_plot(plots,type,scale)
%
% Plots characteristics of the transducer. 
% 'plots' is a strucure containing the performance functions of the
% transducer as returned by XDUCER_PLOTS.M
%
% 'type' is the characteristic that is to be plotted
% 
% II: Input Impedance
% VP: Voltage to Pressure Transfer
% PV: Pressure to Voltage Transfer
% PT: Power Transfer
% IL: 2-way Insertion Loss
%
% 'fignum' is te figure number to plot in
%

freq=plots.freq.scale;
fmin=plots.freq.fmin;
fmax=plots.freq.fmax;
fnum=plots.freq.fnum;
low=min(find(freq>5&freq<10));

II = plots.II;
VP = plots.VP;
PV = plots.PV;
PT = plots.PT;
IL = plots.IL;

try
    impdata=evalin('base','impdata');
catch
    impdata=zeros(100,3);
end
switch lower(type)
    case 'ii'   % Input Impedance
        
        [maxval,index] = max(real(II(low:fnum)));
        fpeak = freq(index+low-1);
        h=figure(fignum);
        set(h,'Name','Input Impedance','position',[5,20,500,700],'Color',[0.5 0.5 0.6]);
        subplot(2,1,1);cla
        h0=line(impdata(:,1)/1e6,abs(complex(impdata(:,2),impdata(:,3))));
        set(h0,'Color','r');
        h1=line(freq,abs(II));
        set(findobj(h,'type','axes'),'yscale','lin');
        if max(abs(II(2:end))) > 2000
            axis([fmin fmax .1 500]);
        else
            axis([fmin fmax .1 max(abs(II))]);
        end
        grid on
        title('Impedance Magnitude');xlabel('f (MHz)');ylabel('Abs(Z) [Ohm]');
        hold on;plot(fpeak,maxval,'r.')
        
        subplot(2,1,2)
        h2=plot(freq,angle(II)*180/pi);
        set(h2,'LineWidth',2);
        h3=line(impdata(:,1)/1e6,angle(complex(impdata(:,2),impdata(:,3)))*180/pi);
        set(h3,'Color','r');
        axis([fmin fmax -150 150]);
        grid on
        title('Impedance Phase');xlabel('f (MHz)');ylabel('Phase(Z) [degrees]');
        hold on;plot(fpeak,imag(II(index+low-1)),'r.');
            
                   
    case 'vp'   % Voltage to Pressure Transfer
        
        [maxval,index] = max(abs(VP));
        fpeak = freq(index);
        [bw,fl,fr] = findbw(abs(VP),freq,index);
        h=figure(fignum);
        set(h,'Name','Voltage to Pressure','position',[5,0,500,700],'Color',[0.5 0.5 0.6]);

        subplot(2,1,1);
        h1=plot(freq,abs(VP));
        set(findobj(h,'type','axes'),'yscale','lin');
        axis([fmin fmax .1 max(abs(VP)) / 0.9]);grid on
        title(['Max = ',num2str(maxval/1e3,2),' kPa/V   BW = ',num2str(bw,2),'%']);xlabel('f (MHz)');ylabel('P_{out} / V_{eff} [Pa / V]');
        hold on;plot(fpeak,maxval,'r.');
        line([freq(index) freq(index)],[10 maxval],'LineWidth',1,'Linestyle','-','color','r');
        line([freq(fl) freq(fr)],[maxval/2 maxval/2],'LineWidth',1,'Linestyle','-','color','r');
        plot(freq(fl),maxval/2,'ro');
        plot(freq(fr),maxval/2,'ro');
        
        subplot(2,1,2)
        h2=plot(freq,180 / pi * (unwrap(angle(VP))+ pi));
        axis([fmin fmax -360 180]);grid on
        title('Angle of Transfer');xlabel('f (MHz)');ylabel('\theta [degrees]');
                     
    case 'pv'   % Pressure to Voltage Transfer
        
        [maxval,index] = max(abs(PV));maxval=maxval*1e6;
        fpeak = freq(index);
        [bw,fl,fr] = findbw(abs(PV),freq,index);
        h=figure(fignum);
        set(h,'Name','Pressure to Voltage','position',[5,0,500,700],'Color',[0.5 0.5 0.6]);
        subplot(2,1,1);
        h1=plot(freq,abs(PV)*1e6);
        set(findobj(h,'type','axes'),'yscale','lin');
        axis([fmin fmax .01 max(abs(PV)) * 1.1e6]);grid on
        title(['Max = ',num2str(maxval,2),' V/MPa   BW = ',num2str(bw,2),'%']);xlabel('f (MHz)');ylabel('V_{out} / P_{in} [V / MPa]');
        hold on;plot(fpeak,maxval,'r.')
        line([freq(index) freq(index)],[.010 maxval],'LineWidth',1,'Linestyle','-','color','r');
        line([freq(fl) freq(fr)],[maxval/2 maxval/2],'LineWidth',1,'Linestyle','-','color','r');
        line(freq(fl),maxval/2,'Linestyle',':','color','r');
        line(freq(fr),maxval/2,'Linestyle',':','color','r');
        
        subplot(2,1,2)
        h2=plot(freq,180 / pi * (unwrap(angle(PV))+ pi));
        axis([fmin fmax -180 180]);grid on
        title('Angle of Transfer');xlabel('f (MHz)');ylabel('\theta [degrees]');
            
        %disp(['Peak frequency: ',num2str(fpeak),' MHz'])
        %disp(['Peak transfer: ',num2str(maxval*1e6) ,' V / MPa'])
        
    case 'pt'   % Power Transfer
        
        [maxval,index] = max(abs(PT));
        fpeak = freq(index);
        [bw,fl,fr] = findbw(abs(PT),freq,index);
        h=figure(fignum);
        set(h,'Name','Power Transfer','position',[5,0,500,700],'Color',[0.5 0.5 0.6]);
        subplot(2,1,1);
        h1=plot(freq,abs(PT));
        axis([fmin fmax 1e-5 max(abs(PT)) * 1.1]);
        grid on
        title(['Max = ',num2str(maxval,2),'  BW = ',num2str(bw,2),'%']);xlabel('f (MHz)');ylabel('P_{out} / P_{in} ');
        hold on;plot(fpeak,maxval,'r.')
        line([freq(index) freq(index)],[1e-5 maxval],'LineWidth',1,'Linestyle','-','color','r');
        line([freq(fl) freq(fr)],[maxval/2 maxval/2],'LineWidth',1,'Linestyle','-','color','r');
        line(freq(fl),maxval/2,'Linestyle','o','color','r');
        line(freq(fr),maxval/2,'Linestyle','o','color','r');
        
        subplot(2,1,2)
        h2=plot(freq,180 / pi * angle(PT));
        axis([fmin fmax -180 180]);grid on
        title('Angle of Transfer');xlabel('f (MHz)');ylabel('\theta [degrees]');
            
    case 'il'   % Insertion loss
        
        [maxval,index] = min(abs(IL));
        fpeak = freq(index);
        h=figure(fignum);
        set(h,'Name','Insertion Loss','position',[5,0,500,700],'Color',[0.5 0.5 0.6]);
        subplot(2,1,1);
        h1=plot(freq,abs(IL));
        axis([fmin fmax 1 100]);grid on
        title('2-way Insertion Loss');xlabel('f (MHz)');ylabel('IL (dB) ');
        hold on;plot(fpeak,maxval,'r.')
        %disp(['Peak frequency: ',num2str(fpeak),' MHz'])
        %disp(['Min. Insertion Loss: ',num2str(maxval), ' dB' ])
        
end
scrsz = get(0,'ScreenSize');
set(h,'position',[0,35,scrsz(3)/2-7,scrsz(4)-105])
subplot(2,1,1),hold off
subplot(2,1,2),hold off
set(h1,'LineWidth',2);
if exist('h2') set(h2,'LineWidth',2); end