function f=costfnc(x,xducer,h1,props)

% function f=costfnc(x,xducer,h1,Layer1,'Property1',value1,..)
% This function applies a minimum search algorithm to maximize the peaks at
% 20 and 40 MHz. The function optimizes the values x(1:n) such that the
% cost function is minimized. xducer is the transducer property structure. 
% h1 is the figure handle for plotting.
% props is a structure containing the properties to vary (see function
% OPTIMIZE

lng=length(props)/3;
if lng~=round(lng) error('Invalid Property arguments');end
for a=1:3:lng*3
    layer=props{a};
    prop=props{a+1};
    value=x((a-1)/3+1);
    if layer > 0
        if strcmp(prop,'diameter')
            for n = 1:length(xducer.layers)
                xducer.layers(n).diameter=value;
            end
        else
            xducer.layers(layer).(prop)=value;
        end
    elseif layer ==0
        xducer.boundaries.(prop)=value;
    else
        xducer.cable.(prop)=value;
    end
end

% Choose properties to optimize:
%xducer.layers(1).thickness = x(1);
%xducer.layers(2).thickness = x(2);
%xducer.layers(2).Z0 = x(3);
%xducer.boundaries.Zback = x(4);
%xducer.layers(3).thickness = x(4);
%xducer.layers(3).Z0 = x(5);

% Calculate current transducer transfer functions
assignin('base','transducer_out',xducer);

plots = xducer_plots(xducer);

freq = plots.freq.scale;

VP = abs(plots.VP);
PV = abs(plots.PV);
PT = plots.PT;

fmax=plots.freq.fmax;
fmin=plots.freq.fmin;
fnum=plots.freq.fnum;

freqstep=(fmax-fmin)/fnum;
sendindex=round((20-fmin)/freqstep);
recindex=round((40-fmin)/freqstep);

% Uncomment to use send and receive frequency
% f=-log(VP(sendindex))-log(PV(recindex));
f= -(VP(sendindex))-(VP(recindex));

% Uncomment to optimize Rik's number
% f=-(VP(sendindex))^2*(PV(recindex));

% Uncomment 
% f=-(VP(sendindex))^2*(PV(recindex));

% Uncomment to use HIC
% [SNR,HIC]=calculate_HIC(xducer);
% f = -HIC;

% Uncomment to use send frequency only
%sendindex=round((30-fmin)/freqstep);
% f=-2*log(VP(sendindex)) ;

% Uncomment to use peak effeciency regardless of frequency
% f = -max(VP);

% Uncomment to use receive frequency only
%f=-2*log(PV(recindex)) ;

% Uncomment to use 18-22 MHz and 38-42 MHz
% send = sum(VP(sendindex-round(2/freqstep):sendindex+round(2/freqstep)));
% receive = sum(PV(recindex-round(2/freqstep):recindex+round(2/freqstep)));
% f = -2 * log(send) - log(receive);

% Uncomment to optimize bandwidth (does not work very well...)
% [maxval,index] = max(VP(1:round(1.5*sendindex)));
% fpeak = freq(index);
% [BW,fl,fr] = findbw(VP,freq,index);
% f =-BW;

% Plotting

set(h1,'XData',freq,'YData',VP,'color','b','LineStyle','-');
set(h1,'LineWidth',2);
set(h1,'EraseMode','xor');
str=[];
for a=1:length(x)
str=[str '  ' char(props{(a-1)*3+2}) ' = ' num2str(x(a),3)];
end

xlabel(str,'FontSize',8,'FontWeight','Bold');

drawnow;