clear all; close all; clc;

% set parameters for cable
PZT_disk.cable.Zc               = 50;
PZT_disk.cable.length           = 1;
PZT_disk.cable.damping          = 0.02;

% set parameters for boundary
z_air                           = 410;
Z_water                         = 1.48e6;
Z_back                          = 2.35e6;

%set parameters voor piezo
diameter                        = 0.01;

%set parameters matching layers
PZT_disk.boundaries.Rint        = 50;
PZT_disk.boundaries.Zback       = z_air;   
PZT_disk.boundaries.Zmedium     = Z_water;
PZT_disk.boundaries.fmin        = 10e6;
PZT_disk.boundaries.fmax        = 30e6;
PZT_disk.boundaries.fnum        = 2048;
%PZT_disk.boundaries.d           = 6e-3;

% set parameters for PZT material
PZT_disk.layers.active          = 'yes';
PZT_disk.layers.number          = 1;
PZT_disk.layers.name            = 'PZT disk';
PZT_disk.layers.comments        = 'CTS';
PZT_disk.layers.thickness       = 105.5e-6;
PZT_disk.layers.diameter        = diameter;
PZT_disk.layers.rho             = 7.87e3;
PZT_disk.layers.c33d            = 1.77e11;
PZT_disk.layers.kt              = 0.539;
PZT_disk.layers.epsilons        = 3800;
PZT_disk.layers.tandelta_m      = 0.03;
PZT_disk.layers.tandelta_e      = 0.02;
PZT_disk.layers.velocity        = [];
PZT_disk.layers.Z0              = []; %40e6;

PZT_disk = addlayer(PZT_disk);

% set parameters for 1/4 lambda layer
PZT_disk.layers(2).active       = 'yes';
PZT_disk.layers(2).number       = 2;
PZT_disk.layers(2).name         = '1/4 lambda';
PZT_disk.layers(2).comments     = 'Acheson';
PZT_disk.layers(2).thickness    = 15e-6;  %10.2/3.6e-6
PZT_disk.layers(2).diameter     = diameter;
%PZT_disk.layers(2).rho         = 10.64e3;
%PZT_disk.layers(2).c33d        = 0;
%PZT_disk.layers(2).kt          = 0;
%PZT_disk.layers(2).epsilons    = 0;
PZT_disk.layers(2).tandelta_m   = 0.0265; % guessed value
%PZT_disk.layers(2).tandelta_e  = 0.00;
PZT_disk.layers(2).velocity     = 1390;
PZT_disk.layers(2).Z0           = 7.6e6;

klm(PZT_disk)