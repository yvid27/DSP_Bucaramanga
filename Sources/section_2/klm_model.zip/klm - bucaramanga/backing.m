function transducer_out = backing(transducer)

% BACKING.M
% Switches between air backing/medium and Eccobond backing/water medium
% Convenient for switching between optimisation and impedance fitting

if transducer.boundaries.Zback<1000;
transducer.boundaries.Zback=7e6;
transducer.boundaries.Zmedium=1.5e6;
else
transducer.boundaries.Zback=410;
transducer.boundaries.Zmedium=410;
end

transducer_out=transducer;