figure(10)
for a = 1:5
    if a<10
        filename=['g:\data\Prototype_v3\rond0' num2str(a)];
    else
        filename=['g:\data\Prototype_v3\rond' num2str(a)];
    end
    impdata=load_data(filename);
    subplot(5,2,2*a-1)
    freq=impdata(:,1)/1e6;
    mag=abs(complex(impdata(:,2),impdata(:,3)));
    phase=angle(complex(impdata(:,2),impdata(:,3)))*180/pi;
    plot(freq,mag);
    grid on;axis([10 60 0 200]);
    set(gca,'FontSize',8);
    xlabel('MHz');ylabel('Magnitude');legend(['Element no.' num2str(a)]);
    subplot(5,2,2*a)
    plot(freq,phase);
    grid on;axis([10 60 -90 0]);
    set(gca,'FontSize',8);
    xlabel('MHz');ylabel('Phase');legend(['Element no.' num2str(a)]);
end

figure(11)
for a = 6:10
    if a<10
        filename=['g:\data\Prototype_v3\rond0' num2str(a)];
    else
        filename=['g:\data\Prototype_v3\rond' num2str(a)];
    end
    impdata=load_data(filename);
    subplot(5,2,2*a-11)
    freq=impdata(:,1)/1e6;
    mag=abs(complex(impdata(:,2),impdata(:,3)));
    phase=angle(complex(impdata(:,2),impdata(:,3)))*180/pi;
    plot(freq,mag);
    grid on;axis([10 60 0 200]);
    set(gca,'FontSize',8);
    xlabel('MHz');ylabel('Magnitude');legend(['Element no.' num2str(a)]);
    subplot(5,2,2*a-10)
    plot(freq,phase);
    grid on;axis([10 60 -90 0]);
    set(gca,'FontSize',8);
    xlabel('MHz');ylabel('Phase');legend(['Element no.' num2str(a)]);
end

figure(12)
for a = 11:15
    if a<10
        filename=['g:\data\Prototype_v3\rond0' num2str(a)];
    else
        filename=['g:\data\Prototype_v3\rond' num2str(a)];
    end
    impdata=load_data(filename);
    subplot(5,2,2*a-21)
    freq=impdata(:,1)/1e6;
    mag=abs(complex(impdata(:,2),impdata(:,3)));
    phase=angle(complex(impdata(:,2),impdata(:,3)))*180/pi;
    plot(freq,mag);
    grid on;axis([10 60 0 200]);
    set(gca,'FontSize',8);
    xlabel('MHz');ylabel('Magnitude');legend(['Element no.' num2str(a)]);
    subplot(5,2,2*a-20)
    plot(freq,phase);
    grid on;axis([10 60 -90 0]);
    set(gca,'FontSize',8);
    xlabel('MHz');ylabel('Phase');legend(['Element no.' num2str(a)]);
end

figure(13)
for a = 16:20
    if a<10
        filename=['g:\data\Prototype_v3\rond0' num2str(a)];
    else
        filename=['g:\data\Prototype_v3\rond' num2str(a)];
    end
    impdata=load_data(filename);
    subplot(5,2,2*a-31)
    freq=impdata(:,1)/1e6;
    mag=abs(complex(impdata(:,2),impdata(:,3)));
    phase=angle(complex(impdata(:,2),impdata(:,3)))*180/pi;
    plot(freq,mag);
    grid on;axis([10 60 0 200]);
    set(gca,'FontSize',8);
    xlabel('MHz');ylabel('Magnitude');legend(['Element no.' num2str(a)]);
    subplot(5,2,2*a-30)
    plot(freq,phase);
    grid on;axis([10 60 -90 0]);
    set(gca,'FontSize',8);
    xlabel('MHz');ylabel('Phase');legend(['Element no.' num2str(a)]);
end