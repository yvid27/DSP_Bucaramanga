function M=make_xform(Phi,omega)

% make_xform(Phi,omega)
%
% Builds the two-port for the transformer in the KLM model

lng=length(omega);
M=ones(2,2,lng);

A=-1./Phi;
B=0;
C=0;
D=-Phi;

M(1,1,:)=A;
M(1,2,:)=B;
M(2,1,:)=C;
M(2,2,:)=D;