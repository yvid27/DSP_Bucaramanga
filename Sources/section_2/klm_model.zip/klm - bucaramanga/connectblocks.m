function M=connectblocks(blocks);

% M=connectblocks(blocks);
%
% Connects individual two-ports to a single two-port. 
% blocks=[block 1 block 2 ... block n];

n=size(blocks,2)/2;     %number of blocks
M=blocks(:,1:2,:);

for a=1:n-1
    M2=blocks(:,(2*a+1):(2*a+2),:);
    M=ndmtimes(M,M2);
end

