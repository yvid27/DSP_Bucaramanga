function fitgui(transducer)

% FITGUI is a GUI that is used for fitting the KLM model to measured
% impedance data. This M-file lets the user select the parameters to vary
% and the starting values. This information is passed to the file FIT.M
%
% transducer is the transducer model structure
%
% The user can load impedance data in the gui. If there exist a variable
% 'impdata' in the workspace, this data is used for fitting
%

fig_props = { ...
    'name'                   'Choose parameters' ...
    'resize'                 'off' ...
    'numbertitle'            'off' ...
    'menubar'                'none' ...
    'visible'                'on' ...
    'createfcn'              ''    ...
    'position'               [250 250 700 500]   ...
    'closerequestfcn'        'delete(gcbf)' ...
      };
  
fig = figure(fig_props{:});

uicontrol('style','frame',...
          'position',[4 4 695 495]);


% checkbox positions
p0 = 470;

uicontrol('style','text',...
                    'position',[25 p0+5 250 15],...
                    'string','Boundary conditions',...
                    'HorizontalAlignment','Left','FontWeight','Bold'); 

props = fieldnames(transducer.boundaries);



for a = 1:length(fieldnames(transducer.boundaries))
    boundcheckboxes(a) = uicontrol('style','checkbox',...
                    'position',[25 p0-20*a 15 15]);
    boundtexts = uicontrol('style','text',...
                    'position',[45 p0-20*a 60 15],...
                    'string',props{a},...
                    'HorizontalAlignment','Left'); 
    boundvals(a) = uicontrol('style','edit',...
                    'position',[110 p0-20*a 75 18],...
                    'string',transducer.boundaries.(props{a}));
end

p0 = 500-250;
uicontrol('style','text',...
                    'position',[25 p0+5 250 15],...
                    'string','Piezo properties',...
                    'HorizontalAlignment','Left','FontWeight','Bold'); 
props = fieldnames(transducer.layers(1));

for a = 1:8
    piezocheckboxes(a) = uicontrol('style','checkbox',...
                    'position',[25 p0-20*a 15 15]);
    piezotexts = uicontrol('style','text',...
                    'position',[45 p0-20*a 60 15],...
                    'string',props{a+4},...
                    'HorizontalAlignment','Left'); 
    piezovals(a) = uicontrol('style','edit',...
                    'position',[110 p0-20*a 75 18],...
                    'string',transducer.layers(1).(props{a+4}));
end


uicontrol('style','text',...
                    'position',[250 p0+5 250 15],...
                    'string','Layer properties',...
                    'HorizontalAlignment','Left','FontWeight','Bold'); 

p0 = 500-270;
propindex = [5 11 13 14];
layercheckboxes=[];layervals=[];
for a = 1:4          
    layertexts = uicontrol('style','text',...
                    'position',[250 p0-20*a 60 15],...
                    'string',props{propindex(a)},...
                    'HorizontalAlignment','Left'); 
                
    for n = 2:length(transducer.layers)
    p1 = 120 + n*100;
    props = fieldnames(transducer.layers(n));

        if a==1
            uicontrol('style','text',...
                    'position',[p1+25 p0+5 80 15],...
                    'string',transducer.layers(n).name,...
                    'HorizontalAlignment','Left','FontWeight','Bold'); 
        end
        layercheckboxes(a,n-1) = uicontrol('style','checkbox',...
                    'position',[p1 p0-20*a 15 15]);
        
        layervals(a,n-1) = uicontrol('style','edit',...
                    'position',[p1+25 p0-20*a 60 18],...
                    'string',transducer.layers(n).(props{propindex(a)}));
    end
end

ok_btn = uicontrol('style','pushbutton',...
                   'string','OK',...
                   'position',[10 10 70 20],...
                   'callback',{@doOK,transducer,boundcheckboxes,piezocheckboxes,layercheckboxes,...
                       boundvals,piezovals,layervals});

load_btn = uicontrol('style','pushbutton',...
                   'string','Load Data',...
                   'position',[10 40 70 20],...
                   'callback',@doLOAD);
               
close_btn = uicontrol('style','pushbutton',...
                   'string','Close',...
                   'position',[90 10 70 20],...
                   'callback','close(gcf)');               
               
checks = evalin('base','checks','[]');

if ~isempty(checks)
    for a = 1:3
        set(boundcheckboxes(a),'Value' , checks{1}(a));
    end
    for a = 1:8
        set(piezocheckboxes(a),'Value' , checks{2}(a));
    end
    for a = 1:4
        for n = 2:length(transducer.layers)
            set(layercheckboxes(a,n-1),'Value' , checks{3}(a,n-1));
        end
    end
end

function doLOAD(load_btn,evd)
impdata = load_data;
assignin('base','impdata',impdata);

function doOK(ok_btn,evd,transducer,boundcheckboxes,piezocheckboxes,layercheckboxes,boundvals,piezovals,layervals)

n=1;
paramlist=[];
checks1 = []; checks2 = []; checks3 = [];

props = fieldnames(transducer.boundaries);
for a = 1:length(fieldnames(transducer.boundaries))
    checks1 = [checks1 get(boundcheckboxes(a),'Value')];
   if get(boundcheckboxes(a),'Value') == 1
        paramlist{n} = 0;
        paramlist{n+1} = char(props{a});
        paramlist{n+2} = str2double(get(boundvals(a),'String'));
        n=n+3;
    end
end

props = fieldnames(transducer.layers(1));
for a = 1:8
    checks2 = [checks2 get(piezocheckboxes(a),'Value')];
    if get(piezocheckboxes(a),'Value') == 1
        paramlist{n} = 1;
        paramlist{n+1} = char(props{a+4});
        paramlist{n+2} = str2double(get(piezovals(a),'String'));
        n=n+3;
    end
end

propindex = [5 11 13 14];
for a=1:4
    for k = 2:length(transducer.layers)
        props = fieldnames(transducer.layers(k));
        checks3(a,k-1) = get(layercheckboxes(a,k-1),'Value');
        if get(layercheckboxes(a,k-1),'Value') == 1
            paramlist{n} = k;
            paramlist{n+1} = char(props{propindex(a)});
            paramlist{n+2} = str2double(get(layervals(a,k-1),'String'));
            n=n+3;
        end
    end
end

assignin('base','checks',{checks1,checks2,checks3});
assignin('base','paramlist',paramlist);
impdata=evalin('base','impdata','zeros(1,1)');
close(gcf)
x = fit(transducer,impdata,paramlist);               
assignin('base','x',x);             