function impdata = load_data(filename)

% LOAD_DATA reads impedance measurements from the HP VectorImp
% The data is stored in a nx3 array, where n is the number of data points
% The first column contains the frequency data, the scond column contains
% the real part of the impedance data and the third column contains the
% imaginary impednace data.
%
if nargin<1
    
wd=cd;
[filename,path] = uigetfile('*.*', 'Open a file from the Labview environment');

if (filename~=0)
    [path,filename]
file = fopen([path,filename],'r','ieee-be');

% geprobeerd:

[data, count] = fread(file,inf,'float32');

fclose(file);

numberop = count / 3;

freqs = data(1:numberop);
realdata = data(numberop+1:2*numberop);
imagdata = data(2*numberop+1:3*numberop);

freqs=freqs';
realdata=realdata';
imagdata=imagdata';

[Selection,ok] = listdlg('ListString',{'Veerpenprobe','Koperen probe','Kogeltjesprobe','No correction'},'SelectionMode','Single','initialValue',2,'Name','Probeselectie','PromptString','Welke probe?','ListSize',[120 60]);

switch Selection
    case []
        error('You have to select a probe type!');
    case 1
        
    case 2
    
        % compensate for Cu-probe
        realdata = realdata - 0.566 - 3.44E-9 * freqs;                  
        imagdata = imagdata + 0.02 - 1.67e-7 * freqs;
        % Accuracy +/- 0.02 Ohm

    case 3
        % compensate for kogeltjesprobe
        realdata = realdata - 0.455 - 8.55E-9 * freqs;                  
        imagdata = imagdata - 0.151 - 2.58e-8 * freqs;
        % Accuracy +/- 0.1 Ohm
    case 4
        
        
end
% calculate abs and angle:

impdata=[freqs' realdata' imagdata'];

else
    error('No file. Stop.');
end

else
    
file = fopen(filename,'r','ieee-be');

% geprobeerd:

[data, count] = fread(file,inf,'float32');

fclose(file);

numberop = count / 3;

freqs = data(1:numberop);
realdata = data(numberop+1:2*numberop);
imagdata = data(2*numberop+1:3*numberop);

freqs=freqs';
realdata=realdata';
imagdata=imagdata';

realdata = realdata - 0.566 - 3.44E-9 * freqs;                  
imagdata = imagdata + 0.02 - 1.67e-7 * freqs;

impdata=[freqs' realdata' imagdata'];

end