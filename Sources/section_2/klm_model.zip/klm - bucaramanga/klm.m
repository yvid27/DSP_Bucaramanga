function varargout = klm(varargin)
% KLM M-file for klm.fig
%      KLM, by itself, creates a new KLM or raises the existing
%      singleton*.
%
%      H = KLM returns the handle to a new KLM or the handle to
%      the existing singleton*.
%
%      KLM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in KLM.M with the given input arguments.
%
%      KLM('Property','Value',...) creates a new KLM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before klm_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to klm_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help klm

% Last Modified by GUIDE v2.5 31-Mar-2004 08:42:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @klm_OpeningFcn, ...
                   'gui_OutputFcn',  @klm_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before klm is made visible.
function klm_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to klm (see VARARGIN)
set(handles.figure1,'Color',[.5 .5 .6]);

% Check for arguments
if isempty(varargin)
    error('Please specify a transducer structure to work with');
else
    handles.transducer = varargin{1};
    handles.input = varargin{1};
end

% Update handles structure
guidata(hObject, handles);

transducer = handles.transducer;
layernames{1} = 'boundaries';
layernames{2} = 'cable';
for a = 1:length(transducer.layers)
    layernames{a+2} = transducer.layers(a).name;
end
set(handles.popupmenu1,'String',layernames,'Value',1);
set(handles.popupmenu2,'String',fieldnames(transducer.boundaries),'Value',1);
handles.currentlayer=-1;
handles.currentprop='Rint';
set(handles.edit1,'String',transducer.boundaries.Rint);
set(handles.slider1,'Value',transducer.boundaries.Rint);
set(handles.slider1,'Max',2*transducer.boundaries.Rint);

% Show trasnducer properties in separate figure (no. 2)
show_xducer(handles.transducer,2);

guidata(hObject, handles);



% --- Outputs from this function are returned to the command line.
function varargout = klm_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.transducer;


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

transducer=handles.transducer;
layerlist=get(hObject,'String');
handles.currentlayer=get(hObject,'Value')-2;
handles.currentprop='active';

if handles.currentlayer == -1
    
    set(handles.popupmenu2,'String',fieldnames(transducer.boundaries),'Value',1);
    set(handles.edit1,'String',transducer.boundaries.Rint);
    set(handles.slider1,'Value',transducer.boundaries.Rint);
    set(handles.slider1,'Max',2*transducer.boundaries.Rint);
    set(handles.slider1,'Visible','On');
    handles.currentprop='Rint';
    
elseif handles.currentlayer == 0
    
    set(handles.popupmenu2,'String',fieldnames(transducer.cable),'Value',1);
    set(handles.edit1,'String',transducer.cable.Zc);
    set(handles.slider1,'Value',transducer.cable.Zc);
    set(handles.slider1,'Max',2*transducer.cable.Zc);
    set(handles.slider1,'Visible','On');
    handles.currentprop='Zc';
    
else
    
    set(handles.popupmenu2,'String',fieldnames(transducer.layers(handles.currentlayer)),'Value',1);
    set(handles.edit1,'String',transducer.layers(handles.currentlayer).active);
    set(handles.slider1,'Visible','Off');
    
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2

transducer = handles.transducer;
contents = get(hObject,'String');
handles.currentprop=char(contents(get(hObject,'Value')));

if handles.currentlayer == -1 

    set(handles.slider1,'Value',transducer.boundaries.(handles.currentprop));
    set(handles.slider1,'Max',2*transducer.boundaries.(handles.currentprop));
    set(handles.edit1,'String',transducer.boundaries.(handles.currentprop));
    
elseif handles.currentlayer == 0
    
    set(handles.slider1,'Value',transducer.cable.(handles.currentprop));
    set(handles.slider1,'Max',2*transducer.cable.(handles.currentprop));
    set(handles.edit1,'String',transducer.cable.(handles.currentprop));
    
else
    
    if (~isstr(transducer.layers(handles.currentlayer).(handles.currentprop)) & ~isempty(transducer.layers(handles.currentlayer).(handles.currentprop)))
        set(handles.slider1,'Value',transducer.layers(handles.currentlayer).(handles.currentprop));
        set(handles.slider1,'Max',2*transducer.layers(handles.currentlayer).(handles.currentprop));
        set(handles.slider1,'Visible','On');
        
    else
        
        set(handles.slider1,'Visible','Off');
        
    end
    
    set(handles.edit1,'String',transducer.layers(handles.currentlayer).(handles.currentprop));
    
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
transducer=handles.transducer;
if handles.currentlayer==-1
    
    transducer.boundaries.(handles.currentprop)=str2double(get(handles.edit1,'String'));
    set(handles.slider1,'Value',transducer.boundaries.(handles.currentprop));
    set(handles.slider1,'Max',2*transducer.boundaries.(handles.currentprop));
    
elseif handles.currentlayer==0
    
    transducer.cable.(handles.currentprop)=str2double(get(handles.edit1,'String'));
    set(handles.slider1,'Value',transducer.cable.(handles.currentprop));
    set(handles.slider1,'Max',2*transducer.cable.(handles.currentprop));
    
else
    
    if  ~isnan(str2double(get(handles.edit1,'String')))
        transducer.layers(handles.currentlayer).(handles.currentprop)=str2double(get(handles.edit1,'String'));
        set(handles.slider1,'Value',transducer.layers(handles.currentlayer).(handles.currentprop));
        set(handles.slider1,'Max',2*transducer.layers(handles.currentlayer).(handles.currentprop));
        set(handles.slider1,'Visible','On');
        
    else
    
        transducer.layers(handles.currentlayer).(handles.currentprop)=(get(handles.edit1,'String'));
        set(handles.slider1,'Visible','Off');
        
    end
    
end

handles.transducer=transducer;
assignin('base','transducer_out',transducer)
guidata(hObject, handles);
show_xducer(handles.transducer,2);

% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

transducer=handles.transducer;
plottypenr = get(handles.popupmenu3,'Value');
types={'II','VP','PV','PT','IL'};
plottype=types{plottypenr};
plots=xducer_plots(transducer);
make_plot(plots,1,plottype);
assignin('base','transducer_out',transducer);

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
transducer=handles.transducer;

if handles.currentlayer==-1
    transducer.boundaries.(handles.currentprop)=get(hObject,'Value');
    set(handles.edit1,'String',transducer.boundaries.(handles.currentprop));
elseif handles.currentlayer==0
    transducer.cable.(handles.currentprop)=get(hObject,'Value');
    set(handles.edit1,'String',transducer.cable.(handles.currentprop));
else
    transducer.layers(handles.currentlayer).(handles.currentprop)=get(hObject,'Value');
    set(handles.edit1,'String',transducer.layers(handles.currentlayer).(handles.currentprop));
end


handles.transducer=transducer;
assignin('base','transducer_out',transducer)

guidata(hObject, handles);

plottypenr = get(handles.popupmenu3,'Value');
types={'II','VP','PV','PT','IL','WF'};
plottype=types{plottypenr};
plots=xducer_plots(transducer);
make_plot(plots,1,plottype);
show_xducer(handles.transducer,2);

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

transducer=handles.transducer;
handles.transducer=handles.input;
transducer=handles.transducer;
set(handles.popupmenu1,'Value',1);
set(handles.popupmenu2,'Value',1);
handles.currentlayer=0;
handles.currentprop='active';
set(handles.edit1,'String',transducer.boundaries.Rint);
set(handles.slider1,'Value',transducer.boundaries.Rint);
set(handles.slider1,'Max',2*transducer.boundaries.Rint);
guidata(hObject, handles);