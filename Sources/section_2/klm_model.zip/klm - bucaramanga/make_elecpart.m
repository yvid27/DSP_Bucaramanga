function M=make_elecpart(C0,X1,omega)

% Builds the capacitor and inductance of the KLM model

lng=length(omega);
M=ones(2,2,lng);

A=1;
B=1 ./ ( j * omega * C0 ) + j * X1;
C=0;
D=1;

M(1,1,:)=A;
M(1,2,:)=B;
M(2,1,:)=C;
M(2,2,:)=D;