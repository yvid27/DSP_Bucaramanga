function transducer_out = rmlayer(transducer,number)

% RMLAYER removes a layer from the transducer structure
%
% Number is the layer number to be removed
%

countlayers=length(transducer.layers);

if number == countlayers    % remove last layer
    transducer.layers=transducer.layers(1:number-1)
else    % intermediate layer
    
    % change layer numbers of the layers after the layer to be removed
    for a=number+1:countlayers
        transducer.layers(a).number=transducer.layers(a).number-1;
    end
    % remove layer
    transducer.layers=transducer.layers([1:number-1 number+1:countlayers]);
end
transducer_out = transducer;




