function M=make_deadbranch(transducer)

% MAKE_DEADBRANCH(Zb,Z0,l,gamma)
%
% Construct a matrix M for a shunt impedance representing a 
% backing layer impedance, consisting of a transmission line with 
% characteristic impedance Z0, propagation constant gamma and length l:
%
%gamma is an array of propagation constants as a function of frequency
%
% This function is also used to model an extra layer between the backing
% and the piezo layer. The sound velocity in this layer can be defined in
% this file

gamma = transducer.layers(1).gamma;
l = transducer.layers(1).thickness/2;
Z0 = transducer.layers(1).Z0;
Zb = transducer.boundaries.Zback;

try
    d = transducer.boundaries.d; 
catch 
    d = 0; 
end
try 
    Z = transducer.boundaries.Z; 
catch 
    Z = 1; % 0 gives divide-by-zero, value does not matter
end
lng=length(gamma);

% AL:
% velocity = 6400; % Z = 17.3e6
% AU:
 velocity = 3240; tandm = 0.01; % Z = 63.8e6;
% CU: 
% velocity = 5010; % Z = 44.6e6;
% SN: 
% velocity = 3320; % Z = 24.2e6;
% ACH
% velocity = 1200; % Z = 24.2e6;

area = pi * (transducer.layers(1).diameter/2).^2;
Zcb = Zb * area;
Zc = Z0 * area;
freq = linspace(transducer.boundaries.fmin,transducer.boundaries.fmax,transducer.boundaries.fnum);
omega = 2 * pi * freq;
gamma0 = j .* omega ./ velocity .* (1 - j * tandm);
tml = make_tml(Zc,l,gamma);
tml2 = make_tml(Z*area,d,gamma0);
tml3 = connectblocks([tml tml2]);
Zshunt = transfer(tml3,Zcb,'ii');

M = ones(2,2,lng);
A=1;
B=0;
C=1./Zshunt;
D=1;

M(1,1,:)=A;
M(1,2,:)=B;
M(2,1,:)=C;
M(2,2,:)=D;