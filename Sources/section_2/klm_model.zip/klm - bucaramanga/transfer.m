function T=transfer(M,Zl,type)

% TRANSFER  Calculates transfer and impedance functions of the system M
%
% M is a 2x2xN matrix representing the system
% Zl is the load impedance
% type is:
%   ii - input impedance
%   vt - voltage transfer
%   ct - current transfer
%   pt - power tranfer

A = M(1,1,:);
B = M(1,2,:);
C = M(2,1,:);
D = M(2,2,:);

switch lower(type)
    case 'ii'
        T = (A .* Zl + B) ./ (C .* Zl + D);
    case 'vt'
        T = Zl ./ (A .* Zl + B);
    case 'ct'
        T = 1 ./ (C .* Zl + D);
    case 'pt'
        % Power transfer should be real, so take the inner products (E1.I1) /
        % (E2.I2)
        T = Zl ./ ( real(A .* Zl + B) .* real(C .* Zl + D) + imag(A .* Zl + B) .* imag(C .* Zl + D) );
    case 'vc'
        T = 1 ./ (A .* Zl + B);
end

% Make T a (1 by n) vector
T = reshape(T,[1 size(M,3)]);