function M=make_tml(Zc,l,gamma)

% MAKE_TML(Zc,l,gamma)
%
% Construct a matrix M representing a transmission line with acoustic point impedance Zc (=Z0*A), 
% propagation constant gamma and length l:
%
%gamma is an array of propagation constants as a function of frequency

lng=length(gamma);
M=ones(2,2,lng);

A=cosh(gamma.*l);
B=Zc.*sinh(gamma.*l);
C=1./Zc.*sinh(gamma.*l);
D=cosh(gamma.*l);

M(1,1,:)=A;
M(1,2,:)=B;
M(2,1,:)=C;
M(2,2,:)=D;