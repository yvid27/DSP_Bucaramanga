function x=optimize(transducer,varargin)

% OPTIMIZE is an optimization routine that searches for the set of
% parameter values that maximizes the efficiency of the transducer at 20
% and 40 MHz. The cost function can be modified in the file COSTFNC.M.
%
% The syntax is:
% X = OPTIMIZE(transducer, layer, property, value, layer, property, value,
%               ...)
% where 
% - transducer is the transducer structure to be used
% - layer -1 is the cable, layer 0 are the boundaries and layer 1:n are
%   the layers.
% - property is the property name as used in the transducer structure.
% - value is the starting value used in the optimisation.
%
% X is an array with the optimised values

props=varargin;
show_xducer(transducer,2)

lng=length(varargin)/3;
if lng~=round(lng) error('Invalid Property arguments');end
for a=1:lng
    x0(a)=varargin{a*3};
end

scrsz = get(0,'ScreenSize');
figure(3)
hold on
plots=xducer_plots(transducer);
plot(plots.freq.scale,abs(plots.VP),'g');
set(3,'Name','Transducer Properties','Position',[7 scrsz(4)/3-10 scrsz(3)/1.5 scrsz(4)/1.7],...
    'ButtonDownFcn','close');
h1=plot(1,1);grid on ;axis([0 60 0 10e4])

ylabel('Transfer','FontSize',8,'FontWeight','Bold');
hold on
str=[];
for a=1:length(x0)
str=[str '  ' char(props{(a-1)*3+2}) ' = ' num2str(x0(a),2)];
end
title(str,'FontSize',8,'FontWeight','Bold');

fmax=plots.freq.fmax;
fmin=plots.freq.fmin;
fnum=plots.freq.fnum;

% freqstep=(fmax-fmin)/fnum;
% sendindex=round((40-fmin)/freqstep);
% recindex=round((20-fmin)/freqstep);
% si = plots.freq.scale(sendindex);
% ri = plots.freq.scale(recindex);
% 
% h=line([si si],[0 10e4]);
% set(h,'Color','r');
% h=line([ri ri],[0 10e4]);
% set(h,'Color','r');

options=optimset('MaxIter',20000,'TolX',1e-8);
x=fminsearch(@costfnc,x0,options,transducer,h1,props);

