function show_xducer(transducer,propfig)

transducer.layers(1).velocity = round(sqrt(transducer.layers(1).c33d / transducer.layers(1).rho));
transducer.layers(1).Z0 = 1e5*round(1e-5*transducer.layers(1).rho * transducer.layers(1).velocity);

scrsz = get(0,'ScreenSize');

figure(propfig);cla
set(propfig,'Name','Transducer Properties','Position',[scrsz(3)/2 scrsz(4)/3 scrsz(3)/2 2*scrsz(4)/3-80],...
    'ButtonDownFcn','close','Color',[0.5 0.5 0.6]);
axis off
axis([0 1.5 0 1])

text(0,1,'Boundary Conditions','FontSize',10,'FontWeight','Bold','Color','b')
text(0.7,1,'Cable','FontSize',10,'FontWeight','Bold','Color','b')

bnd=fieldnames(transducer.boundaries);
text(0,.8,bnd,'FontSize',8,'FontWeight','Bold')

for a=1:length(bnd)
    bndvals{a}=transducer.boundaries.(bnd{a});
end

text(.3,.8,bndvals,'FontSize',8,'FontWeight','Bold','Color',[0.8 0.8 .9]);

cable=fieldnames(transducer.cable);
text(0.6,.868,cable,'FontSize',8,'FontWeight','Bold')

line([.53 .53],[.68 .92],'Color','k')
line([1.05 1.05],[.68 .92],'Color','k')


for a=1:length(cable)
    cablevals{a}=transducer.cable.(cable{a});
end

text(.9,.868,cablevals,'FontSize',8,'FontWeight','Bold','Color',[0.8 0.8 .9]);

text(0,.55,'Layer Properties','FontSize',10,'FontWeight','Bold','Color','b')

str=fieldnames(transducer.layers(1));
text(0,.25,str,'FontSize',8,'FontWeight','Bold','Interpreter','None')

for a=1:length(transducer.layers)
    for b=1:length(str)
        if ~isstr(transducer.layers(a).(str{b})) 
            strvals{b}=num2str(transducer.layers(a).(str{b}),3); 
        else
            strvals{b}=transducer.layers(a).(str{b});
        end
        line([.53+.3*(a-1) .53+.3*(a-1)],[.02 .48],'Color','k')
    end
    text(.3+.3*(a-1),.25,strvals,'FontSize',8,'FontWeight','Bold','Interpreter','None','Color',[0.8 0.8 .9])
end

