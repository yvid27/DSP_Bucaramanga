%het maken van spectrum plotjes
%plot(y(:,1),y(:,2))
%plot(y(:,1),y(:,3))
a = 0
b = 0
aantal=9
hold on
for a =1:aantal
    %if a<10
        filename=['\\home\users\gerritd\data\projecten\RTD\tdhpc\maart\element ' num2str(a) ' rvs pz27 '];
        %else
        %filename=['g:\data\Prototype_v3\rond' num2str(a)];
        %end
   %impdata=y
   %filename=['\\home\users\gerritd\data\tdhpc\WBbronnen\bron 1 kaal'];
    impdata=load_data(filename);
    %subplot(5,2,2*a-1)
    freq=impdata(:,1)/1e6;
    mag=abs(complex(impdata(:,2),impdata(:,3)));
    phase=angle(complex(impdata(:,2),impdata(:,3)))*180/pi;
    %if num2str(a)= ' '
    %    print num2str;
    %end
    if a>14
       b=a
       a=a-15;
       end
       if a==1
        kleur='b';
       end
    if a==2
        kleur='g';
       end
    if a==3
       kleur='r';
       end
    if a==4
       kleur='c';
       end
    if a==5
       kleur='m';
       end
    if a==6
       kleur='y';
       end                     
    if a==7
       kleur='k'
        end
    if a==8
        kleur='b:';
       end
    if a==9
        kleur='g:';
       end
    if a==10
       kleur='r:';
       end
    if a==11
       kleur='c:';
       end
    if a==12
       kleur='m:';
       end
    if a==13
       kleur='y:';      
    end                     
    if a==14
       kleur='k:'; 
    end
    if b>14
        a=a+14;
        b =0;
    end
    %end
    %plot(freq,mag,kleur);
    plot(impdata(:,1),impdata(:,3),kleur);
    grid on;%axis([10 60 0 200]);
    %set(gca,'FontSize',8);
    xlabel('MHz');ylabel('Magnitude');%legend(['Element no.' num2str(a)]);
    %subplot(5,2,2*a)
    %plot(freq,phase,kleur);
    %grid on;%axis([10 60 -90 0]);
    %set(gca,'FontSize',8);
    %xlabel('MHz');ylabel('Phase');legend(['Element no.' num2str(a)]);
end
hold off
