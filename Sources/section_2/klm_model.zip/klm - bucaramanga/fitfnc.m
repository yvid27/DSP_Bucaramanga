function f=fitfnc(x,xducer,impdata,h1,h3,h5,props,range)

global COUNT
global F

lng=length(props)/3;
if lng~=round(lng) error('Invalid Property arguments');end
for a=1:3:lng*3
    layer=props{a};
    prop=props{a+1};
    value=x((a-1)/3+1);
    if layer ~= 0
        if strcmp(prop,'diameter')
            for n = 1:length(xducer.layers)
                xducer.layers(n).diameter=value;
            end
        else
            xducer.layers(layer).(prop)=value;
        end
    else
        xducer.boundaries.(prop)=value;
    end
end

assignin('base','transducer_fit',xducer);
% Calculate current transducer transfer functions
plots = xducer_plots(xducer);
freq = plots.freq.scale;

% determine frequency scale
fmax=plots.freq.fmax;
fmin=plots.freq.fmin;
fnum=plots.freq.fnum;
freqstep=(fmax-fmin)/fnum;

% determine range
f1 = range(1);
f2 = range(2);
index1 = round((f1-fmin)/freqstep);
index2 = round((f2-fmin)/freqstep);

% retrieve model and measurement data
II = plots.II(index1:index2).';
realdata=impdata(index1:index2,2);
imagdata=impdata(index1:index2,3);
absdata=abs(complex(realdata,imagdata));
phasedata=angle(complex(realdata,imagdata)*180/pi);

f = sum((realdata-real(II)).^2) + sum((imagdata-imag(II)).^2);       
  

F = [F f];
COUNT = [COUNT COUNT(end)+1];
% Plotting

set(h1,'EraseMode','xor');
set(h1,'XData',freq,'YData',real(plots.II));
set(h1,'LineWidth',1,'Color','r');

set(h3,'EraseMode','xor');
set(h3,'XData',freq,'YData',imag(plots.II));
set(h3,'LineWidth',1,'Color','r');

% set(h5,'EraseMode','xor');
% set(h5,'XData',COUNT,'YData',F);
% set(h5,'LineWidth',2,'Color','g');
% if rem(COUNT(end),25)==0
%     set(gca,'YLim',[f-3 f+3]);
% end
error1 = abs(realdata-real(II))+abs(imagdata-imag(II));
set(h5,'EraseMode','xor');
set(h5,'XData',freq(index1:index2),'YData',error1);
set(h5,'LineWidth',2,'Color','m');
axes(get(h5(1),'Parent'))
set(gca,'XLim',[freq(index1) freq(index2)],'YLim',[.01 100],'Yscale','Lin');



str=[];
for a=1:length(x)
str=[str '  ' char(props{(a-1)*3+2}) ' = ' num2str(x(a),3)];
end

xlabel([str '  ' ],'FontSize',8,'FontWeight','Bold');  

drawnow;


