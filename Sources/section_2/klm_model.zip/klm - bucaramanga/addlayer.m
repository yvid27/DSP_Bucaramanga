function transducer_out = addlayer(transducer)

% ADDLAYER adds an  layer to the transducer structure
%
% By default, diameter and thickness are the same as the previous layer in
% the structure. The layer is set to active. The other fields are empty.
%

number=length(transducer.layers)+1;

% Copy previous layer
transducer.layers(number)=transducer.layers(number-1);

transducer.layers(number).active='yes';
transducer.layers(number).name=[];
transducer.layers(number).comments=[];
transducer.layers(number).number=number;
transducer.layers(number).rho=[];
transducer.layers(number).c33d=[];
transducer.layers(number).kt=[];
transducer.layers(number).epsilons=[];
transducer.layers(number).tandelta_m=[];
transducer.layers(number).tandelta_e=[];
transducer.layers(number).velocity=[];
transducer.layers(number).Z0=[];

transducer_out=transducer;