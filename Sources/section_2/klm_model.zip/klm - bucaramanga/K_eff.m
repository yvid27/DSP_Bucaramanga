%berekenen van de effectieve koppelfactor;
%input resonantie frequentie en antiresonantie frequentie;

resf = input('geef de reronantie frequentie in Hz = ');
anresf = input ('geef de antiresonantie frequentie in Hz anresf = ');

Keff = sqrt((anresf^2-resf^2)/anresf^2)
