function Minv=inverseblock(M)

% Minv=inverseblock(M)
%
% Calculates the inverse Minv of 2x2xn matrix M, page-by page
% Code is vectorized.

A = M(1,1,:);
B = M(1,2,:);
C = M(2,1,:);
D = M(2,2,:);

detM = A .* D - B .* C;

Minv(1,1,:) =  D ./ detM;
Minv(1,2,:) = -B ./ detM;
Minv(2,1,:) = -C ./ detM;
Minv(2,2,:) =  A ./ detM;