function M=make_twoport(type,imp,value,omega)

% MAKE_TWOPORT(type,imp,value,omega)
%
% Construct a two-port of type:
%
% s: serial
% p: parallel
%
% With the following impedance:
%
% R: resistive
% C: capacitive 
% L: inductive
% Phi: Transformer (function of omega)
%
% omega is the frequency scale

lng=length(omega);
M=ones(2,2,lng);
one=ones(1,lng);
zero=zeros(1,lng);

switch lower(imp)
    case 'r'
        Z(1:lng)=value;
    case 'c'
        Z(1:lng)=1./(i*omega*value);
    case 'l'
        Z(1:lng)=i.*omega.*value;
    case 'phi'
        if size(value)~=lng error(' Phi and omega must have equal dimensions'); end
end
        
if lower(imp)~='phi'
    switch lower(type)
        case 's'
            A=one;
            B=Z;
            C=zero;
            D=one;
        case 'p'
            A=one;
            B =zero;
            C=1./Z;
            D=one;
    end
else
        A=1./value;
        B=zero;
        C=zero;
        D=value;
end

M(1,1,:)=A;
M(1,2,:)=B;
M(2,1,:)=C;
M(2,2,:)=D;