function plots=xducer_plots(transducer)

% plots=xducer_plots(transducer)
%
% Returns the calculated performance of the transducer
%
% plots.freq:   Frequency scale [MHz]
% plots.II:     Input Impedance
% plots.VP:     Voltage to Pressure Transfer
% plots.PV:     Pressure to Voltage Transfer
% plots.PT:     Power Transfer
% plots.IL:     2-way Insertion Loss
% plots.IR:     Impulse response waveform


% Calculate transducer matrix
[M,transducer_out,freq] = build_xducer(transducer);

boundaries=transducer_out.boundaries;
layers_out=transducer_out.layers;
% Point Impedance of the medium
Zc = boundaries.Zmedium*layers_out(1).area;
Rint = boundaries.Rint;

% Frequency scale for plotting
freq=freq/1e6;

fmin=boundaries.fmin/1e6;
fmax=boundaries.fmax/1e6;
fnum=boundaries.fnum;

% Calculate transfer characteristics
II = transfer(M,Zc,'ii');

% Function 'transfer' really calculates Voltage input to Force output,
% because we use point impedances (see Kino). We therefore devide by the
% area to obtain Voltage to Pressure transfer:
VP = transfer(M,Zc,'vt') ./ layers_out(1).area;

VP = VP .* II ./ (Rint + II);           % Voltage available to transducer is 
                                        % less than output voltage from
                                        % amplifier due to internal
                                        % resistance of the amplifier,
                                        % hence the voltage divider term
                                        
% Calculate voltage to pressure of inv(M). This corresponds to calculating 
% pressure to voltage of M. Since the function 'transfer' calculates Force input to
% Voltage output, we have to multiply by the area to obtain Pressure to
% Voltage transfer.
% The load impedance looking from the medium into the transducer is just the 
% internal resistance of the amplifier. It is negative because the currents
% flow in opposite direction

% Uncomment to use custom Preamp
% Rint = 2000;
PV = transfer(inverseblock(M),-Rint,'vt') .* layers_out(1).area;






% Calculate the input impedance of the transducer seen from the medium. This is
% divided by the area to go from electric to acoustic impedance.

Zin = transfer(inverseblock(M),-Rint,'ii') ./ layers_out(1).area;
PV = PV .* Zin ./ (Zin - boundaries.Zmedium)*2;
                                        % Pressure available to transducer is 
                                        % less than output pressure from
                                        % medium due to finite acoustic
                                        % impedance of the medium resulting in 
                                        % reflections, hence the voltage divider term
                                        
% The minus signs in the equations above and the factor of 2 are due to sign conventions of
% v,F,I and V. The theory is not completely worked out
                                        
% Power transmission coefficient
ptc = 1 - ( abs( (Rint - II) ./ (Rint + II) ) ).^2;
% Power transfer
PT = ptc .* transfer(M,Zc,'pt');

% 2-way Insertion Loss. Factor 2 from pressure doubling at perfect
% reflector
IL = 20 * log10( abs(VP .* PV) .* 2 );

% Pressure waveform, as calculated by inverse fft
% Make pulse in time domain
WF = make_pulse(transducer,50);

% Transform into freq. domain
Fv = fft(WF.v);

% Calculate V to P transfer in freq. domain

VP2 = [VP conj(VP(end:-1:2))];

% Multiply to get Pressure output in freq. domain
P = Fv .* VP2;

%Transfrom back to time domain
p = real(ifft(P));
WF.p = p;

% Pass frequency scale and performance data
plots.freq.scale=freq;
plots.freq.fmin=fmin;
plots.freq.fmax=fmax;
plots.freq.fnum=fnum;
plots.II=II;
plots.VP=VP;
plots.PV=PV;
plots.PT=PT;
plots.IL=IL;
plots.WF=WF;