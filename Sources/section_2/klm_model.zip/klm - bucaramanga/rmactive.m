%x=transducer_out.boundaries;
%x=rmfield(x,'active');
%transducer_out.boundaries=x;
x=transducer_out.cable;
x=rmfield(x,'active');
transducer_out.cable=x;